package com.STInnovations.snap_prove_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
