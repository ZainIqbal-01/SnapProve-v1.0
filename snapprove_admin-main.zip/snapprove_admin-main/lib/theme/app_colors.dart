import 'package:flutter/material.dart';

class AppColors {

  // Extended Color Palette
  static const Color primary02635D = Color(0xFF02635D); // Dark Cyan - Trust & Stability
  static const Color accent = Color(0xFF07D673);  // Vivid Green - Success & Security
  static const Color accentLight = Color(0xFFe8f8f3);  // Vivid Green - Success & Security
  static const Color secondary = Color(0xFF004A41); // Dark Turquoise - Depth & Professionalism

  // Neutral Colors
  static const Color background = Color(0xFFF8FAFC); // Almost White - Background
  static const Color card = Color(0xFFE2E8F0);      // Light Gray - Cards & Dividers
  static const Color divider = Color(0xFFE2E8F0);   // Light Gray - Cards & Dividers
  static const Color secondaryText = Color(0xFF64748B); // Slate Gray - Secondary Text
  static const Color secondaryText2 = Color(0xFF84aba9); // Slate Gray - Secondary Text
  static const Color primaryText = Color(0xFF1E293B);   // Dark Slate - Primary Text
  static const Color textFieldFillColor = Color(0xFFf3f3f5);   // Dark Slate - Primary Text

  // Status Colors
  static const Color success = Color(0xFF07D673); // Success
  static const Color warning = Color(0xFFF59E0B); // Warning
  static const Color error = Color(0xFFEF4444);   // Error
  static const Color info = Color(0xFF3B82F6);    // Info

  static const whiteFFFFFF = Color(0xFFFFFFFF);
  static const black000000 = Color(0xFF000000);
  static const greyD0DBEA = Color(0xFFA3A9B3);
  static const grey9FA5C0 = Color(0xFF9FA5C0);
  static const redFF0000 = Color(0xFFFF0000);
  static const blue3E5481 = Color(0xFF3E5481);
  static const grey5B5B5B = Color(0xFF5B5B5B);
  static const greyEFEFEF = Color(0xFFEFEFEF);
  static const green3DD34C = Color(0xFF3DD34C);
  static const greenB2F2BB = Color(0xFFB2F2BB);
  static const lightBlue66CCFF = Color(0xFF66CCFF);
  static const lightBlue89CDEF = Color(0xFF89CDEF);

  static const purple7012CE = Color(0xFF7012CE);
  static const redE60000 = Color(0xFFE60000);
  static const red990000 = Color(0xFF990000);
  static const redFFE5E5 = Color(0xFFFFE5E5);

  static const blue004466 = Color(0xFF004466);
  static const blue0088CC = Color(0xFF0088CC);
}
