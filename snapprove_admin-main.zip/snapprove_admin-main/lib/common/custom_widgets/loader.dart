//   Show Loader
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import 'loader_view.dart';

showLoader(context) {
  return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return const PopScope(canPop: false, child: LoaderView());
      });
}

// loader.dart
showLoaderRouteNAv(BuildContext context) {
  return showDialog(
    barrierDismissible: false,
    useRootNavigator: true, // ✅ important
    context: context,
    builder: (context) {
      return const PopScope(
        canPop: false,
        child: LoaderView(),
      );
    },
  );
}


class LoaderView extends StatelessWidget {
  const LoaderView({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child:  Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.secondary),
            ),


          ],
        ),
      ),
    );
  }
}