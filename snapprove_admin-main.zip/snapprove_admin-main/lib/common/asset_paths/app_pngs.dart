class AppPngs {
  static const String customAvatar = "assets/pngs/";
  // static const String logo = "assets/pngs/logo.png";
  static const String logo22 = "assets/pngs/logo22.png";
  static const String secure = "assets/pngs/secure.png";
  static const String video = "assets/pngs/video.png";
  static const String save = "assets/pngs/save.png";

  static const String avatar1 = "assets/pngs/avatar1.png";
  static const String childProfile = "assets/pngs/child_profile.png";
  static const String quiz = "assets/pngs/quiz.png";
  static const String timeout = "assets/pngs/timeout.png";
}
