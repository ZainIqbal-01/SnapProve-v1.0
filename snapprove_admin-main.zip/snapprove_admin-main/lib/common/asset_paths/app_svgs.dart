class AppSvgs {
  static const String cam = 'assets/svgs/cam.svg';
  static const String image = 'assets/svgs/image.svg';
  static const String files = 'assets/svgs/files.svg';
  static const String payment = 'assets/svgs/payment.svg';
  static const String attach = 'assets/svgs/attach.svg';

}
