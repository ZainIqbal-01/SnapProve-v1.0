import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';




class Responsive {
  // Breakpoints
  static const double mobileBreakpoint = 800;
  static const double tabletBreakpoint = 1050;
  static const double webBreakpoint = 1400;

  // Max content width for web
  static const double maxContentWidth = 1400;

  // Screen size helpers
  static bool isMobile(BuildContext context) =>
      MediaQuery.of(context).size.width < mobileBreakpoint;

  static bool isTablet(BuildContext context) =>
      MediaQuery.of(context).size.width >= mobileBreakpoint &&
          MediaQuery.of(context).size.width < tabletBreakpoint;

  static bool isWeb(BuildContext context) =>
      MediaQuery.of(context).size.width >= tabletBreakpoint;

  // FIXED: Consistent breakpoint logic with other methods
  static Size screenUtilDesignSize(double width) {
    if (width >= tabletBreakpoint) { // Changed from webBreakpoint to tabletBreakpoint
      return const Size(1440, 900);
    } else if (width >= mobileBreakpoint) { // Changed from tabletBreakpoint to mobileBreakpoint
      return const Size(1024, 768);
    } else {
      return const Size(393, 852);
    }
  }

  static ScreenSize getScreenSize(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width < mobileBreakpoint) return ScreenSize.mobile;
    if (width < tabletBreakpoint) return ScreenSize.tablet;
    return ScreenSize.web;
  }

  // ... rest of your methods remain the same
  static double responsiveFontSize(BuildContext context, {
    double mobile = 14,
    double tablet = 16,
    double web = 18,
  }) {
    final size = getScreenSize(context);
    switch (size) {
      case ScreenSize.mobile:
        return mobile;
      case ScreenSize.tablet:
        return tablet;
      case ScreenSize.web:
        return web;
    }
  }

  static EdgeInsetsGeometry responsivePadding(BuildContext context, {
    EdgeInsets? mobile,
    EdgeInsets? tablet,
    EdgeInsets? web,
  }) {
    final size = getScreenSize(context);
    switch (size) {
      case ScreenSize.mobile:
        return mobile ?? const EdgeInsets.all(16);
      case ScreenSize.tablet:
        return tablet ?? const EdgeInsets.symmetric(horizontal: 32, vertical: 24);
      case ScreenSize.web:
        return web ?? const EdgeInsets.symmetric(horizontal: 48, vertical: 32);
    }
  }

  static int responsiveColumnCount(BuildContext context) {
    final size = getScreenSize(context);
    switch (size) {
      case ScreenSize.mobile:
        return 2;
      case ScreenSize.tablet:
        return 3;
      case ScreenSize.web:
        return 4;
    }
  }

  static double containerWidth(BuildContext context, {int columns = 1}) {
    final screenSize = getScreenSize(context);
    final screenWidth = MediaQuery.of(context).size.width;

    if (screenSize == ScreenSize.web) {
      final availableWidth = screenWidth.clamp(0, maxContentWidth);
      return (availableWidth / responsiveColumnCount(context)) * columns -
          (24 * (columns - 1));
    }

    final percentage = columns / responsiveColumnCount(context);
    return screenWidth * percentage - (16 * (columns - 1));
  }
}
enum ScreenSize { mobile, tablet, web }