import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:snap_prove_admin/view/landing_view/landing_view_screen.dart';

import '../../common/services/auth_services.dart';
import '../../common/utils/common_function.dart';
import '../auth/login_view.dart';



class SplashServices {
  void isLogin(BuildContext context) async {
    print('--------------------------');
    final auth = FirebaseAuth.instance;
    final user = auth.currentUser;
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    print(prefs.getBool('rememberMe'));
    if (prefs.getBool('rememberMe') == false ||
        prefs.getBool('rememberMe') == null) {
      AuthServices().signOut();
      Timer(
          const Duration(seconds: 1),
          () => Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => LoginView())));
    } else {
      print(user != null);
      if (user != null) {
        // String? phoneNull = await getPhone();
        // String? status = await FirestoreService().getUserStatus(user.email!);

        // if(status == 'Activate'){
        //   // if(phoneNull == ''){
        //   //   Timer(const Duration(seconds: 2), () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> SignInWithPhone()))  );
        //   //
        //   // }else{
        //   Timer(const Duration(seconds: 2), () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> LandingView()))  );
        //
        //   // }
        // }else{


        Timer(
            const Duration(seconds: 1),
            () => Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => LandingView())));
        // showDialogStatus(context, 'User is deactivated by admin, Kindly contact admin');
      }

      // }
      else {
        Timer(
            const Duration(seconds: 1),
            () => Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => LoginView())));
      }
    }
  }
}
