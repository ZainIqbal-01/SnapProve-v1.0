import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../model/user_model.dart';

class UsersProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<UserModel> _users = [];
  List<UserModel> _filteredUsers = [];
  bool _isLoading = false;
  String _searchQuery = '';
  String _filterStatus = 'all'; // all, verified, unverified, blocked

  List<UserModel> get users => _filteredUsers;
  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;
  String get filterStatus => _filterStatus;

  // Fetch all users
  Future<void> fetchUsers() async {
    _isLoading = true;
    notifyListeners();

    try {
      final QuerySnapshot snapshot = await _firestore.collection('users').get();
      _users = snapshot.docs.map((doc) => UserModel.fromFirestore(doc)).toList();
      _applyFilters();
    } catch (e) {
      print('Error fetching users: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Search users
  void searchUsers(String query) {
    _searchQuery = query.toLowerCase();
    _applyFilters();
    notifyListeners();
  }

  // Filter users by status
  void filterByStatus(String status) {
    _filterStatus = status;
    _applyFilters();
    notifyListeners();
  }

  // Apply filters and search
  void _applyFilters() {
    _filteredUsers = _users.where((user) {
      // Search filter
      final matchesSearch = _searchQuery.isEmpty ||
          user.fullName.toLowerCase().contains(_searchQuery) ||
          user.email.toLowerCase().contains(_searchQuery) ||
          user.phoneNumber.contains(_searchQuery);

      // Status filter
      bool matchesStatus = true;
      switch (_filterStatus) {
        case 'verified':
          matchesStatus = user.isVerified;
          break;
        case 'unverified':
          matchesStatus = !user.isVerified;
          break;
        case 'blocked':
          matchesStatus = user.isBlocked;
          break;
        case 'all':
        default:
          matchesStatus = true;
      }

      return matchesSearch && matchesStatus;
    }).toList();
  }

  // Block/Unblock user
  Future<bool> toggleBlockUser(String uid, bool currentBlockStatus) async {
    try {
      await _firestore.collection('users').doc(uid).update({
        'isBlocked': !currentBlockStatus,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Update local state
      final index = _users.indexWhere((user) => user.uid == uid);
      if (index != -1) {
        _users[index] = _users[index].copyWith(isBlocked: !currentBlockStatus);
        _applyFilters();
        notifyListeners();
      }

      return true;
    } catch (e) {
      print('Error toggling block status: $e');
      return false;
    }
  }

  // Update CNIC verification status
  Future<bool> updateCnicStatus(String uid, String status) async {
    try {
      await _firestore.collection('users').doc(uid).update({
        'cnicStatus': status,
        'cnicVerified': status == 'approved',
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Update local state
      final index = _users.indexWhere((user) => user.uid == uid);
      if (index != -1) {
        _users[index] = _users[index].copyWith(
          cnicStatus: status,
          cnicVerified: status == 'approved',
        );
        _applyFilters();
        notifyListeners();
      }

      return true;
    } catch (e) {
      print('Error updating CNIC status: $e');
      return false;
    }
  }

  // Update Face Scan verification status
  Future<bool> updateFaceScanStatus(String uid, String status) async {
    try {
      await _firestore.collection('users').doc(uid).update({
        'faceScanStatus': status,
        'isVerified': status == 'approved',
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Update local state
      final index = _users.indexWhere((user) => user.uid == uid);
      if (index != -1) {
        _users[index] = _users[index].copyWith(faceScanStatus: status);
        _applyFilters();
        notifyListeners();
      }

      return true;
    } catch (e) {
      print('Error updating face scan status: $e');
      return false;
    }
  }



  // Get user by ID
  UserModel? getUserById(String uid) {
    try {
      return _users.firstWhere((user) => user.uid == uid);
    } catch (e) {
      return null;
    }
  }

  // Refresh single user data
  Future<UserModel?> refreshUserData(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        final user = UserModel.fromFirestore(doc);
        final index = _users.indexWhere((u) => u.uid == uid);
        if (index != -1) {
          _users[index] = user;
          _applyFilters();
          notifyListeners();
        }
        return user;
      }
      return null;
    } catch (e) {
      print('Error refreshing user data: $e');
      return null;
    }
  }
}