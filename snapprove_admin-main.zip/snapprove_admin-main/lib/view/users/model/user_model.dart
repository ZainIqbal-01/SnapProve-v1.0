import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String fullName;
  final String email;
  final String phoneNumber;
  final String? profileImageUrl;
  final String? cnicNumber;
  final String? cnicFrontImageUrl;
  final String? cnicBackImageUrl;
  final String? cnicStatus; // pending, approved, rejected
  final bool cnicVerified;
  final String? faceScanVideoUrl;
  final String? faceScanStatus; // pending, approved, rejected
  final bool isFaceScanned;
  final String? dateOfBirth;
  final String? gender;
  final bool isVerified;
  final bool isUserDetailsComplete;
  final List<String> scannedDeals;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final DateTime? lastScannedAt;
  final DateTime? faceScanUploadedAt;
  final String? fcmToken;
  final String? nameLowerCase;
  final DateTime? tokenUpdatedAt;
  final bool isBlocked; // For block/unblock functionality

  UserModel({
    required this.uid,
    required this.fullName,
    required this.email,
    required this.phoneNumber,
    this.profileImageUrl,
    this.cnicNumber,
    this.cnicFrontImageUrl,
    this.cnicBackImageUrl,
    this.cnicStatus,
    this.cnicVerified = false,
    this.faceScanVideoUrl,
    this.faceScanStatus,
    this.isFaceScanned = false,
    this.dateOfBirth,
    this.gender,
    this.isVerified = false,
    this.isUserDetailsComplete = false,
    this.scannedDeals = const [],
    this.createdAt,
    this.updatedAt,
    this.lastScannedAt,
    this.faceScanUploadedAt,
    this.fcmToken,
    this.nameLowerCase,
    this.tokenUpdatedAt,
    this.isBlocked = false,
  });

  // From Firestore
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      fullName: data['fullName'] ?? '',
      email: data['email'] ?? '',
      phoneNumber: data['phoneNumber'] ?? '',
      profileImageUrl: data['profileImageUrl'],
      cnicNumber: data['cnicNumber'],
      cnicFrontImageUrl: data['cnicFrontImageUrl'],
      cnicBackImageUrl: data['cnicBackImageUrl'],
      cnicStatus: data['cnicStatus'],
      cnicVerified: data['cnicVerified'] ?? false,
      faceScanVideoUrl: data['faceScanVideoUrl'],
      faceScanStatus: data['faceScanStatus'],
      isFaceScanned: data['isFaceScanned'] ?? false,
      dateOfBirth: data['dateOfBirth'],
      gender: data['gender'],
      isVerified: data['isVerified'] ?? false,
      isUserDetailsComplete: data['isUserDetailsComplete'] ?? false,
      scannedDeals: List<String>.from(data['scannedDeals'] ?? []),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      lastScannedAt: (data['lastScannedAt'] as Timestamp?)?.toDate(),
      faceScanUploadedAt: (data['faceScanUploadedAt'] as Timestamp?)?.toDate(),
      fcmToken: data['fcmToken'],
      nameLowerCase: data['nameLowerCase'],
      tokenUpdatedAt: (data['tokenUpdatedAt'] as Timestamp?)?.toDate(),
      isBlocked: data['isBlocked'] ?? false,
    );
  }

  // To Firestore
  Map<String, dynamic> toFirestore() {
    return {
      'uid': uid,
      'fullName': fullName,
      'email': email,
      'phoneNumber': phoneNumber,
      'profileImageUrl': profileImageUrl,
      'cnicNumber': cnicNumber,
      'cnicFrontImageUrl': cnicFrontImageUrl,
      'cnicBackImageUrl': cnicBackImageUrl,
      'cnicStatus': cnicStatus,
      'cnicVerified': cnicVerified,
      'faceScanVideoUrl': faceScanVideoUrl,
      'faceScanStatus': faceScanStatus,
      'isFaceScanned': isFaceScanned,
      'dateOfBirth': dateOfBirth,
      'gender': gender,
      'isVerified': isVerified,
      'isUserDetailsComplete': isUserDetailsComplete,
      'scannedDeals': scannedDeals,
      'createdAt': createdAt != null ? Timestamp.fromDate(createdAt!) : null,
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
      'lastScannedAt': lastScannedAt != null ? Timestamp.fromDate(lastScannedAt!) : null,
      'faceScanUploadedAt': faceScanUploadedAt != null ? Timestamp.fromDate(faceScanUploadedAt!) : null,
      'fcmToken': fcmToken,
      'nameLowerCase': nameLowerCase,
      'tokenUpdatedAt': tokenUpdatedAt != null ? Timestamp.fromDate(tokenUpdatedAt!) : null,
      'isBlocked': isBlocked,
    };
  }

  // Copy with
  UserModel copyWith({
    String? uid,
    String? fullName,
    String? email,
    String? phoneNumber,
    String? profileImageUrl,
    String? cnicNumber,
    String? cnicFrontImageUrl,
    String? cnicBackImageUrl,
    String? cnicStatus,
    bool? cnicVerified,
    String? faceScanVideoUrl,
    String? faceScanStatus,
    bool? isFaceScanned,
    String? dateOfBirth,
    String? gender,
    bool? isVerified,
    bool? isUserDetailsComplete,
    List<String>? scannedDeals,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? lastScannedAt,
    DateTime? faceScanUploadedAt,
    String? fcmToken,
    String? nameLowerCase,
    DateTime? tokenUpdatedAt,
    bool? isBlocked,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      fullName: fullName ?? this.fullName,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      cnicNumber: cnicNumber ?? this.cnicNumber,
      cnicFrontImageUrl: cnicFrontImageUrl ?? this.cnicFrontImageUrl,
      cnicBackImageUrl: cnicBackImageUrl ?? this.cnicBackImageUrl,
      cnicStatus: cnicStatus ?? this.cnicStatus,
      cnicVerified: cnicVerified ?? this.cnicVerified,
      faceScanVideoUrl: faceScanVideoUrl ?? this.faceScanVideoUrl,
      faceScanStatus: faceScanStatus ?? this.faceScanStatus,
      isFaceScanned: isFaceScanned ?? this.isFaceScanned,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      gender: gender ?? this.gender,
      isVerified: isVerified ?? this.isVerified,
      isUserDetailsComplete: isUserDetailsComplete ?? this.isUserDetailsComplete,
      scannedDeals: scannedDeals ?? this.scannedDeals,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastScannedAt: lastScannedAt ?? this.lastScannedAt,
      faceScanUploadedAt: faceScanUploadedAt ?? this.faceScanUploadedAt,
      fcmToken: fcmToken ?? this.fcmToken,
      nameLowerCase: nameLowerCase ?? this.nameLowerCase,
      tokenUpdatedAt: tokenUpdatedAt ?? this.tokenUpdatedAt,
      isBlocked: isBlocked ?? this.isBlocked,
    );
  }
}