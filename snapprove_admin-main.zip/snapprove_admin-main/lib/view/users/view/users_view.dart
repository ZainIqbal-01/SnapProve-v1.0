import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import 'package:snap_prove_admin/view/users/view/user_details_view.dart';
import '../../../common/custom_widgets/loader.dart';
import '../provider/user_provider.dart';


class UsersView extends StatefulWidget {
  const UsersView({super.key});

  @override
  State<UsersView> createState() => _UsersViewState();
}

class _UsersViewState extends State<UsersView> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<UsersProvider>().fetchUsers();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Consumer<UsersProvider>(
      builder: (context, provider, child) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            child: Column(
              children: [
                // Search and Filter Section
                _buildSearchAndFilter(context, provider, isMobile, isTablet),

                // Users List
                Expanded(
                  child: provider.isLoading
                      ? Center(child: CircularProgressIndicator())
                      : provider.users.isEmpty
                      ? _buildEmptyState()
                      : _buildUsersList(context, provider, isMobile, isTablet),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSearchAndFilter(BuildContext context, UsersProvider provider, bool isMobile, bool isTablet) {
    return Container(
      padding: EdgeInsets.all(isMobile ? 12 : (isTablet ? 16 : 20)),
      color: Colors.white,
      child: Column(
        children: [
          // Search Bar
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) => provider.searchUsers(value),
                  decoration: InputDecoration(
                    hintText: 'Search by name, email, or phone...',
                    prefixIcon: Icon(Icons.search),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                      icon: Icon(Icons.clear, ),
                      onPressed: () {
                        _searchController.clear();
                        provider.searchUsers('');
                      },
                    )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.blue),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ),
              if (!isMobile) ...[
                SizedBox(width: 16),
                _buildRefreshButton(provider),
              ],
            ],
          ),
          SizedBox(height: 12),

          // Filter Chips
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildFilterChip('All', 'all', provider, isMobile),
                      SizedBox(width: 8),
                      _buildFilterChip('Verified', 'verified', provider, isMobile),
                      SizedBox(width: 8),
                      _buildFilterChip('Unverified', 'unverified', provider, isMobile),
                      SizedBox(width: 8),
                      _buildFilterChip('Blocked', 'blocked', provider, isMobile),
                    ],
                  ),
                ),
              ),
              if (isMobile) ...[
                SizedBox(width: 8),
                _buildRefreshButton(provider),
              ],
            ],
          ),

          // Results count
          SizedBox(height: 8),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              '${provider.users.length} user(s) found',
              style: TextStyle(
                color: Colors.grey.shade600,
                fontSize: isMobile ? 12 : 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRefreshButton(UsersProvider provider) {
    return IconButton(
      icon: Icon(Icons.refresh),
      onPressed: () => provider.fetchUsers(),
      tooltip: 'Refresh',
      style: IconButton.styleFrom(
        backgroundColor: AppColors.accent.withValues(alpha: 0.2),
        foregroundColor: AppColors.accent,
      ),
    );
  }

  Widget _buildFilterChip(String label, String value, UsersProvider provider, bool isMobile) {
    final isSelected = provider.filterStatus == value;
    return ChoiceChip(
      checkmarkColor: AppColors.whiteFFFFFF,
      label: Text(
        label,
        style: TextStyle(
          fontSize: isMobile ? 12 : 14,
          fontWeight: FontWeight.w600,
        ),
      ),
      selected: isSelected,
      onSelected: (selected) {
        provider.filterByStatus(value);
      },
      selectedColor: AppColors.secondary,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : Colors.grey.shade700,
      ),
      backgroundColor: Colors.grey.shade100,
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 8 : 12, vertical: 4),
    );
  }

  Widget _buildUsersList(BuildContext context, UsersProvider provider, bool isMobile, bool isTablet) {
    if (isMobile) {
      return _buildMobileUsersList(context, provider);
    } else if (isTablet) {
      return _buildTabletUsersList(context, provider);
    } else {
      return _buildDesktopUsersList(context, provider);
    }
  }

  // Mobile: Card-based list
  Widget _buildMobileUsersList(BuildContext context, UsersProvider provider) {
    return RefreshIndicator(
      onRefresh: () => provider.fetchUsers(),
      child: ListView.builder(
        padding: EdgeInsets.all(12),
        itemCount: provider.users.length,
        itemBuilder: (context, index) {
          final user = provider.users[index];
          return _buildMobileUserCard(context, user, provider);
        },
      ),
    );
  }

  Widget _buildMobileUserCard(BuildContext context, user, UsersProvider provider) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => _navigateToUserDetail(context, user),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  // Profile Image
                  CircleAvatar(
                    radius: 24,
                    backgroundImage: user.profileImageUrl != null
                        ? NetworkImage(user.profileImageUrl!)
                        : null,
                    child: user.profileImageUrl == null
                        ? Text(user.fullName[0].toUpperCase())
                        : null,
                  ),
                  SizedBox(width: 12),

                  // Name and verification badges
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                user.fullName,
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (user.isVerified && user.cnicVerified)
                              Icon(Icons.verified, color: AppColors.accent, size: 18),
                            if (user.isBlocked)
                              Icon(Icons.block, color: AppColors.error, size: 18),
                          ],
                        ),
                        SizedBox(height: 4),
                        Text(
                          user.email,
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 12),

              // Phone
              Row(
                children: [
                  Icon(Icons.phone, size: 14, color: Colors.grey),
                  SizedBox(width: 4),
                  Text(
                    user.phoneNumber,
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                  ),
                ],
              ),
              SizedBox(height: 12),

              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _toggleBlockUser(context, user, provider),
                      icon: Icon(
                        user.isBlocked ? Icons.check_circle : Icons.block,
                        size: 16,
                      ),
                      label: Text(
                        user.isBlocked ? 'Unblock' : 'Block',
                        style: TextStyle(fontSize: 12),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: user.isBlocked ? AppColors.accent : AppColors.error,
                        side: BorderSide(
                          color: user.isBlocked ? AppColors.accent : AppColors.error,
                        ),
                        padding: EdgeInsets.symmetric(vertical: 8),
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _navigateToUserDetail(context, user),
                      icon: Icon(Icons.visibility, size: 16),
                      label: Text('View', style: TextStyle(fontSize: 12)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(vertical: 8),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Tablet: 2-column grid
  Widget _buildTabletUsersList(BuildContext context, UsersProvider provider) {
    return GridView.builder(
      padding: EdgeInsets.all(16),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.5,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: provider.users.length,
      itemBuilder: (context, index) {
        final user = provider.users[index];
        return _buildTabletUserCard(context, user, provider);
      },
    );
  }

  Widget _buildTabletUserCard(BuildContext context, user, UsersProvider provider) {
    return Card(
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => _navigateToUserDetail(context, user),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundImage: user.profileImageUrl != null
                        ? NetworkImage(user.profileImageUrl!)
                        : null,
                    child: user.profileImageUrl == null
                        ? Text(user.fullName[0].toUpperCase(), style: TextStyle(fontSize: 18))
                        : null,
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                user.fullName,
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (user.isVerified && user.cnicVerified)
                              Icon(Icons.verified, color: AppColors.accent, size: 16),
                            if (user.isBlocked)
                              Icon(Icons.block, color: AppColors.error, size: 16),
                          ],
                        ),
                        SizedBox(height: 2),
                        Text(
                          user.email,
                          style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Text(
                user.phoneNumber,
                style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
              ),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _toggleBlockUser(context, user, provider),
                      child: Text(
                        user.isBlocked ? 'Unblock' : 'Block',
                        style: TextStyle(fontSize: 11),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: user.isBlocked ? AppColors.accent : AppColors.error,
                        side: BorderSide(color: user.isBlocked ? AppColors.accent : AppColors.error),
                        padding: EdgeInsets.symmetric(vertical: 6),
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _navigateToUserDetail(context, user),
                      child: Text('View', style: TextStyle(fontSize: 11)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(vertical: 6),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Desktop: List view with cards
  Widget _buildDesktopUsersList(BuildContext context, UsersProvider provider) {
    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: provider.users.length,
      itemBuilder: (context, index) {
        final user = provider.users[index];

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 2,
          color: AppColors.whiteFFFFFF,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Avatar
                CircleAvatar(
                  radius: 22,
                  backgroundImage: user.profileImageUrl != null
                      ? NetworkImage(user.profileImageUrl!)
                      : null,
                  child: user.profileImageUrl == null
                      ? Text(
                    user.fullName[0].toUpperCase(),
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  )
                      : null,
                ),

                const SizedBox(width: 16),

                // User info
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user.fullName,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        user.email,
                        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        user.phoneNumber,
                        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),

                // Status chips
                Expanded(
                  flex: 2,
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      Chip(
                        label: Text(
                          (user.isVerified && user.cnicVerified) ? 'Verified' : 'Unverified',
                          style: const TextStyle(fontSize: 11),
                        ),
                        backgroundColor: (user.isVerified && user.cnicVerified)
                            ? AppColors.accent.withValues(alpha: 0.2)
                            : Colors.orange.shade50,
                        labelStyle: TextStyle(
                          color: (user.isVerified && user.cnicVerified) ? AppColors.accent : Colors.orange,
                        ),
                      ),
                      if (user.isBlocked)
                        Chip(
                          label: const Text('Blocked', style: TextStyle(fontSize: 11)),
                          backgroundColor:AppColors.error.withValues(alpha: 0.2),
                          labelStyle: const TextStyle(color: AppColors.error),
                        ),
                    ],
                  ),
                ),

                // Actions
                Row(
                  children: [
                    OutlinedButton(
                      onPressed: () => _toggleBlockUser(context, user, provider),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: user.isBlocked ? AppColors.accent : AppColors.error,
                        side: BorderSide(
                          color: user.isBlocked ? AppColors.accent : AppColors.error,
                        ),
                      ),
                      child: Text(
                        user.isBlocked ? 'Unblock' : 'Block',
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () => _navigateToUserDetail(context, user),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('View', style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.people_outline, size: 64, color: Colors.grey.shade400),
          SizedBox(height: 16),
          Text(
            'No users found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade600,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Try adjusting your search or filter',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToUserDetail(BuildContext context, user) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UserDetailView(userId: user.uid),
      ),
    );
  }

  Future<void> _toggleBlockUser(BuildContext context, user, UsersProvider provider) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(user.isBlocked ? 'Unblock User?' : 'Block User?'),
        content: Text(
          user.isBlocked
              ? 'Are you sure you want to unblock ${user.fullName}?'
              : 'Are you sure you want to block ${user.fullName}? They will not be able to use the app.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
                backgroundColor: user.isBlocked ? AppColors.accent : AppColors.error,
                foregroundColor: AppColors.whiteFFFFFF
            ),
            child: Text(user.isBlocked ? 'Unblock' : 'Block'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      // Show loader
      showLoader(context);

      final success = await provider.toggleBlockUser(user.uid, user.isBlocked);

      // Hide loader
      if (context.mounted) Navigator.pop(context);

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              success
                  ? user.isBlocked
                  ? 'User unblocked successfully'
                  : 'User blocked successfully'
                  : 'Failed to update user status',
            ),
            backgroundColor: success ? AppColors.accent : AppColors.error,
          ),
        );
      }
    }
  }
}