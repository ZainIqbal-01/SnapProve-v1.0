import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:intl/intl.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import '../../../common/custom_widgets/loader.dart';
import '../model/user_model.dart';
import '../provider/user_provider.dart';
import '../widgets/image_view_dialog.dart';
import '../widgets/video_view.dart';


class UserDetailView extends StatefulWidget {
  final String userId;

  const UserDetailView({super.key, required this.userId});

  @override
  State<UserDetailView> createState() => _UserDetailViewState();
}

class _UserDetailViewState extends State<UserDetailView> {
  UserModel? _user;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    setState(() => _isLoading = true);
    final provider = context.read<UsersProvider>();
    final user = await provider.refreshUserData(widget.userId);
    setState(() {
      _user = user ?? provider.getUserById(widget.userId);
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'User Details',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.black),
            onPressed: _loadUserData,
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _user == null
          ? _buildErrorState()
          : isMobile
          ? _buildMobileLayout()
          : isTablet
          ? _buildTabletLayout()
          : _buildDesktopLayout(),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 64, color: Colors.red),
          SizedBox(height: 16),
          Text('User not found', style: TextStyle(fontSize: 18)),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Go Back'),
          ),
        ],
      ),
    );
  }

  // Mobile Layout - Single column
  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(12),
      child: Column(
        children: [
          _buildProfileCard(true),
          SizedBox(height: 12),
          _buildPersonalInfoCard(true),
          SizedBox(height: 12),
          _buildActivityCard(true),
          SizedBox(height: 12),
          _buildCNICVerificationCard(true),
          SizedBox(height: 12),
          _buildFaceScanVerificationCard(true),
        ],
      ),
    );
  }

  // Tablet Layout - Two columns with balanced distribution
  Widget _buildTabletLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          // Top row - Profile and Personal Info
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _buildProfileCard(false)),
              SizedBox(width: 16),
              Expanded(child: _buildPersonalInfoCard(false)),
            ],
          ),
          SizedBox(height: 16),

          // Activity card - full width for better proportion
          _buildActivityCard(false),
          SizedBox(height: 16),

          // Verification cards - full width for consistency
          _buildCNICVerificationCard(false),
          SizedBox(height: 16),
          _buildFaceScanVerificationCard(false),
        ],
      ),
    );
  }

  // Desktop Layout - Two columns with better balance
  Widget _buildDesktopLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left Column - 40% width
          Expanded(
            flex: 4,
            child: Column(
              children: [
                _buildProfileCard(false),
                SizedBox(height: 20),
                _buildPersonalInfoCard(false),
                SizedBox(height: 20),
                _buildActivityCard(false),
              ],
            ),
          ),
          SizedBox(width: 20),

          // Right Column - 60% width
          Expanded(
            flex: 6,
            child: Column(
              children: [
                _buildCNICVerificationCard(false),
                SizedBox(height: 20),
                _buildFaceScanVerificationCard(false),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileCard(bool isMobile) {
    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          children: [
            CircleAvatar(
              radius: isMobile ? 50 : 60,
              backgroundImage: _user!.profileImageUrl != null
                  ? NetworkImage(_user!.profileImageUrl!)
                  : null,
              backgroundColor: AppColors.secondary.withOpacity(0.1),
              child: _user!.profileImageUrl == null
                  ? Text(
                _user!.fullName[0].toUpperCase(),
                style: TextStyle(
                  fontSize: isMobile ? 36 : 44,
                  fontWeight: FontWeight.bold,
                  color: AppColors.secondary,
                ),
              )
                  : null,
            ),
            SizedBox(height: 20),
            Text(
              _user!.fullName,
              style: TextStyle(
                fontSize: isMobile ? 20 : 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8),
            Text(
              _user!.email,
              style: TextStyle(
                fontSize: isMobile ? 13 : 14,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                if (_user!.isVerified)
                  _buildStatusBadge('Verified', Icons.verified, AppColors.accent),
                if (_user!.isBlocked)
                  _buildStatusBadge('Blocked', Icons.block, AppColors.error),
                if (!_user!.isUserDetailsComplete)
                  _buildStatusBadge('Incomplete', Icons.warning, Colors.orange),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBadge(String label, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 16),
          SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalInfoCard(bool isMobile) {
    return Card(
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.person_outline, color: AppColors.secondary, size: 24),
                SizedBox(width: 8),
                Text(
                  'Personal Information',
                  style: TextStyle(
                    fontSize: isMobile ? 18 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            _buildInfoRow(Icons.phone_outlined, 'Phone', _user!.phoneNumber, isMobile),
            _buildDivider(),
            _buildInfoRow(Icons.badge_outlined, 'CNIC', _user!.cnicNumber ?? 'Not provided', isMobile),
            _buildDivider(),
            _buildInfoRow(Icons.cake_outlined, 'Date of Birth', _formatDate(_user!.dateOfBirth), isMobile),
            _buildDivider(),
            _buildInfoRow(Icons.person_outline, 'Gender', _user!.gender?.capitalize() ?? 'Not specified', isMobile),
            _buildDivider(),
            _buildInfoRow(Icons.calendar_today_outlined, 'Joined', _formatDate(_user!.createdAt?.toIso8601String()), isMobile),
            _buildDivider(),
            _buildInfoRow(Icons.access_time_outlined, 'Last Scanned', _formatDate(_user!.lastScannedAt?.toIso8601String()), isMobile),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityCard(bool isMobile) {
    return Card(
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.analytics_outlined, color: AppColors.secondary, size: 24),
                SizedBox(width: 8),
                Text(
                  'Activity Summary',
                  style: TextStyle(
                    fontSize: isMobile ? 18 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: _buildActivityStat(
                    icon: Icons.qr_code_scanner,
                    label: 'Scanned Deals',
                    value: '${_user!.scannedDeals.length}',
                    color: AppColors.accent,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: _buildActivityStat(
                    icon: Icons.verified_user_outlined,
                    label: 'Account Status',
                    value: (_user!.isVerified && _user!.cnicVerified) ? 'Verified' : 'Unverified',
                    color: (_user!.isVerified && _user!.cnicVerified) ? AppColors.accent : Colors.orange,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: _buildActivityStat(
                    icon: Icons.check_circle_outline,
                    label: 'Profile Status',
                    value: _user!.isUserDetailsComplete ? 'Complete' : 'Incomplete',
                    color: _user!.isUserDetailsComplete ? AppColors.accent : Colors.orange,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityStat({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 32),
          SizedBox(height: 12),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade600,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildCNICVerificationCard(bool isMobile) {
    return Card(
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.credit_card, color: AppColors.secondary, size: 24),
                    SizedBox(width: 8),
                    Text(
                      'CNIC Verification',
                      style: TextStyle(
                        fontSize: isMobile ? 18 : 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                _buildStatusChip(_user!.cnicStatus),
              ],
            ),
            SizedBox(height: 24),

            if (_user!.cnicFrontImageUrl != null || _user!.cnicBackImageUrl != null) ...[
              Row(
                children: [
                  if (_user!.cnicFrontImageUrl != null)
                    Expanded(
                      child: _buildCNICImageCard(
                        'Front Side',
                        _user!.cnicFrontImageUrl!,
                        isMobile,
                      ),
                    ),
                  if (_user!.cnicFrontImageUrl != null && _user!.cnicBackImageUrl != null)
                    SizedBox(width: 16),
                  if (_user!.cnicBackImageUrl != null)
                    Expanded(
                      child: _buildCNICImageCard(
                        'Back Side',
                        _user!.cnicBackImageUrl!,
                        isMobile,
                      ),
                    ),
                ],
              ),
              SizedBox(height: 24),
            ],

            if ( _user!.cnicStatus == 'pending' && _user!.cnicFrontImageUrl != null) ...[
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.blue, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Review the CNIC images and take action',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.blue.shade900,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _updateCNICStatus('approved'),
                      icon: Icon(Icons.check_circle, size: 20),
                      label: Text('Approve CNIC', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _updateCNICStatus('rejected'),
                      icon: Icon(Icons.cancel, size: 20),
                      label: Text('Reject CNIC', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.error,
                        side: BorderSide(color: AppColors.error, width: 1.5),
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ] else if (_user!.cnicFrontImageUrl == null)
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    Icon(Icons.cloud_upload_outlined, color: Colors.grey.shade500, size: 28),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'CNIC not uploaded yet',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildFaceScanVerificationCard(bool isMobile) {
    return Card(
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.face_outlined, color: AppColors.secondary, size: 24),
                    SizedBox(width: 8),
                    Text(
                      'Face Scan Verification',
                      style: TextStyle(
                        fontSize: isMobile ? 18 : 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                _buildStatusChip(_user!.faceScanStatus),
              ],
            ),
            SizedBox(height: 24),

            if (_user!.faceScanVideoUrl != null) ...[
              InkWell(
                onTap: () => _showVideoPlayer(_user!.faceScanVideoUrl!),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  height: isMobile ? 180 : 250,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade300, width: 2),
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: AppColors.accent.withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.play_circle_filled,
                                size: 64,
                                color: AppColors.accent,
                              ),
                            ),
                            SizedBox(height: 16),
                            Text(
                              'Click to play video',
                              style: TextStyle(
                                color: Colors.grey.shade700,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        top: 12,
                        right: 12,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.videocam, color: Colors.white, size: 16),
                              SizedBox(width: 6),
                              Text(
                                'Video',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 24),
            ],

            if ( _user!.faceScanStatus == 'pending' && _user!.faceScanVideoUrl != null) ...[
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.blue, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Review the face scan video and take action',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.blue.shade900,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _updateFaceScanStatus('approved'),
                      icon: Icon(Icons.check_circle, size: 20),
                      label: Text('Approve Scan', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _updateFaceScanStatus('rejected'),
                      icon: Icon(Icons.cancel, size: 20),
                      label: Text('Reject Scan', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.red,
                        side: BorderSide(color: Colors.red, width: 1.5),
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ] else if (_user!.faceScanVideoUrl == null)
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: Row(
                  children: [
                    Icon(Icons.cloud_upload_outlined, color: Colors.grey.shade500, size: 28),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Face scan not uploaded yet',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCNICImageCard(String label, String imageUrl, bool isMobile) {
    return GestureDetector(
      onTap: () => _showImageViewer(imageUrl, label),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade700,
            ),
          ),
          SizedBox(height: 10),
          Container(
            height: isMobile ? 120 : 150,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300, width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Center(child: CircularProgressIndicator());
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return Center(
                        child: Icon(Icons.error_outline, color: Colors.grey),
                      );
                    },
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.black.withOpacity(0.3),
                        ],
                      ),
                    ),
                  ),
                  Center(
                    child: Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.zoom_in, color: Colors.white, size: 24),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, bool isMobile) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.secondary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 18, color: AppColors.secondary),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Divider(color: Colors.grey.shade200, height: 1),
    );
  }

  Widget _buildStatusChip(String? status) {
    Color bgColor;
    Color textColor;
    String label;
    IconData icon;

    switch (status) {
      case 'approved':
        bgColor = Colors.green.shade50;
        textColor = AppColors.accent;
        label = 'Approved';
        icon = Icons.check_circle;
        break;
      case 'rejected':
        bgColor = Colors.red.shade50;
        textColor = AppColors.error;
        label = 'Rejected';
        icon = Icons.cancel;
        break;
      case 'pending':
        bgColor = Colors.orange.shade50;
        textColor = Colors.orange;
        label = 'Pending';
        icon = Icons.schedule;
        break;
      default:
        bgColor = Colors.grey.shade50;
        textColor = Colors.grey;
        label = 'Not Submitted';
        icon = Icons.upload_outlined;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: textColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: textColor, size: 14),
          SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: textColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null || dateStr.isEmpty) return 'N/A';
    try {
      final date = DateTime.parse(dateStr);
      return DateFormat('MMM dd, yyyy').format(date);
    } catch (e) {
      return dateStr;
    }
  }

  void _showImageViewer(String imageUrl, String title) {
    showDialog(
      context: context,
      builder: (context) => ImageViewerDialog(imageUrl: imageUrl, title: title),
    );
  }

  void _showVideoPlayer(String videoUrl) {
    showDialog(
      context: context,
      builder: (context) => VideoPlayerDialog(videoUrl: videoUrl),
    );
  }

  Future<void> _updateCNICStatus(String status) async {

    showLoader(context);

    final provider = context.read<UsersProvider>();
    final success = await provider.updateCnicStatus(widget.userId, status);
    if (mounted) Navigator.pop(context);

    if (success) {
      await _loadUserData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Text('CNIC status updated to $status'),
              ],
            ),
            backgroundColor: AppColors.accent,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error, color: Colors.white),
                SizedBox(width: 8),
                Text('Failed to update CNIC status'),
              ],
            ),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );
      }
    }
  }

  Future<void> _updateFaceScanStatus(String status) async {
    showLoader(context);

    final provider = context.read<UsersProvider>();
    final success = await provider.updateFaceScanStatus(widget.userId, status);
    if (mounted) Navigator.pop(context);

    if (success) {
      await _loadUserData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Text('Face scan status updated to $status'),
              ],
            ),
            backgroundColor: AppColors.accent,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error, color: Colors.white),
                SizedBox(width: 8),
                Text('Failed to update face scan status'),
              ],
            ),
            backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        );
      }
    }
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}