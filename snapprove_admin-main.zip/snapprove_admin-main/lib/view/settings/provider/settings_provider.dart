import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SettingsProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String _privacyPolicy = '';
  String _termsAndConditions = '';
  String _helpAndSupport = '';

  bool _isLoading = false;
  int _currentTab = 0; // 0: Privacy, 1: Terms, 2: Help

  String get privacyPolicy => _privacyPolicy;
  String get termsAndConditions => _termsAndConditions;
  String get helpAndSupport => _helpAndSupport;
  bool get isLoading => _isLoading;
  int get currentTab => _currentTab;

  void setCurrentTab(int index) {
    _currentTab = index;
    notifyListeners();
  }

  // Fetch all documents
  Future<void> fetchAllDocuments() async {
    _isLoading = true;
    notifyListeners();

    try {
      // Fetch Privacy Policy
      final policyDoc = await _firestore.collection('docs').doc('policy').get();
      if (policyDoc.exists) {
        _privacyPolicy = policyDoc.data()?['content'] ?? '';
      }

      // Fetch Terms and Conditions
      final termsDoc = await _firestore.collection('docs').doc('terms').get();
      if (termsDoc.exists) {
        _termsAndConditions = termsDoc.data()?['content'] ?? '';
      }

      // Fetch Help & Support
      final helpDoc = await _firestore.collection('docs').doc('help').get();
      if (helpDoc.exists) {
        _helpAndSupport = helpDoc.data()?['content'] ?? '';
      }
    } catch (e) {
      print('Error fetching documents: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Update Privacy Policy
  Future<bool> updatePrivacyPolicy(String content) async {
    try {
      await _firestore.collection('docs').doc('policy').set({
        'content': content,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      _privacyPolicy = content;
      notifyListeners();
      return true;
    } catch (e) {
      print('Error updating privacy policy: $e');
      return false;
    }
  }

  // Update Terms and Conditions
  Future<bool> updateTermsAndConditions(String content) async {
    try {
      await _firestore.collection('docs').doc('terms').set({
        'content': content,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      _termsAndConditions = content;
      notifyListeners();
      return true;
    } catch (e) {
      print('Error updating terms and conditions: $e');
      return false;
    }
  }

  // Update Help & Support
  Future<bool> updateHelpAndSupport(String content) async {
    try {
      await _firestore.collection('docs').doc('help').set({
        'content': content,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      _helpAndSupport = content;
      notifyListeners();
      return true;
    } catch (e) {
      print('Error updating help & support: $e');
      return false;
    }
  }
}