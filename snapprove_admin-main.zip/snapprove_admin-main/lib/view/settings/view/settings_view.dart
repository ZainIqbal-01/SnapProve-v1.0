import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import '../../../common/custom_widgets/loader.dart';
import '../provider/settings_provider.dart';

class SettingsView extends StatefulWidget {
  const SettingsView({super.key});

  @override
  State<SettingsView> createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final Map<int, TextEditingController> _controllers = {
    0: TextEditingController(),
    1: TextEditingController(),
    2: TextEditingController(),
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      context.read<SettingsProvider>().setCurrentTab(_tabController.index);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<SettingsProvider>();
      provider.fetchAllDocuments().then((_) {
        _controllers[0]!.text = provider.privacyPolicy;
        _controllers[1]!.text = provider.termsAndConditions;
        _controllers[2]!.text = provider.helpAndSupport;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _controllers.forEach((_, controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Consumer<SettingsProvider>(
      builder: (context, provider, child) {
        return Padding(
          padding: EdgeInsets.all(isMobile ? 12 : (isTablet ? 16 : 20)),
          child: Column(
            children: [
              // Header Card
              // Card(
              //   color: AppColors.whiteFFFFFF,
              //   elevation: 2,
              //   shape: RoundedRectangleBorder(
              //     borderRadius: BorderRadius.circular(12),
              //   ),
              //   child: Container(
              //     width: double.infinity,
              //     padding: EdgeInsets.all(isMobile ? 16 : 20),
              //     child: Row(
              //       children: [
              //         Icon(Icons.settings, color: AppColors.secondary, size: 28),
              //         SizedBox(width: 12),
              //         Expanded(
              //           child: Column(
              //             crossAxisAlignment: CrossAxisAlignment.start,
              //             children: [
              //               Text(
              //                 'App Settings',
              //                 style: TextStyle(
              //                   fontSize: isMobile ? 20 : 24,
              //                   fontWeight: FontWeight.bold,
              //                 ),
              //               ),
              //               SizedBox(height: 4),
              //               Text(
              //                 'Manage privacy policy, terms, and help content',
              //                 style: TextStyle(
              //                   fontSize: isMobile ? 13 : 14,
              //                   color: Colors.grey.shade600,
              //                 ),
              //               ),
              //             ],
              //           ),
              //         ),
              //       ],
              //     ),
              //   ),
              // ),
              // SizedBox(height: 20),

              // Tabs and Content
              Expanded(
                child: Card(
                  color: AppColors.whiteFFFFFF,
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      // Tab Bar
                      Container(
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: Colors.grey.shade200,
                              width: 1,
                            ),
                          ),
                        ),
                        child: TabBar(
                          controller: _tabController,
                          labelColor: AppColors.accent,
                          unselectedLabelColor: Colors.grey.shade600,
                          indicatorColor: AppColors.accent,
                          indicatorWeight: 3,
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: isMobile ? 13 : 14,
                          ),
                          isScrollable: isMobile,
                          tabs: [
                            Tab(
                              icon: Icon(Icons.privacy_tip_outlined, size: isMobile ? 20 : 24),
                              text: 'Privacy Policy',
                            ),
                            Tab(
                              icon: Icon(Icons.description_outlined, size: isMobile ? 20 : 24),
                              text: 'Terms & Conditions',
                            ),
                            Tab(
                              icon: Icon(Icons.help_outline, size: isMobile ? 20 : 24),
                              text: 'Help & Support',
                            ),
                          ],
                        ),
                      ),

                      // Tab Content
                      Expanded(
                        child: provider.isLoading
                            ? Center(child: CircularProgressIndicator())
                            : TabBarView(
                          controller: _tabController,
                          children: [
                            _buildEditorTab(
                              context,
                              controller: _controllers[0]!,
                              label: 'Privacy Policy',
                              hint: 'Enter privacy policy content here...',
                              onSave: () => _saveContent(
                                context,
                                0,
                                provider.updatePrivacyPolicy,
                              ),
                              isMobile: isMobile,
                            ),
                            _buildEditorTab(
                              context,
                              controller: _controllers[1]!,
                              label: 'Terms & Conditions',
                              hint: 'Enter terms and conditions content here...',
                              onSave: () => _saveContent(
                                context,
                                1,
                                provider.updateTermsAndConditions,
                              ),
                              isMobile: isMobile,
                            ),
                            _buildEditorTab(
                              context,
                              controller: _controllers[2]!,
                              label: 'Help & Support',
                              hint: 'Enter help and support content here...',
                              onSave: () => _saveContent(
                                context,
                                2,
                                provider.updateHelpAndSupport,
                              ),
                              isMobile: isMobile,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEditorTab(
      BuildContext context, {
        required TextEditingController controller,
        required String label,
        required String hint,
        required VoidCallback onSave,
        required bool isMobile,
      }) {
    return Padding(
      padding: EdgeInsets.all(isMobile ? 12 : 20),
      child: Column(
        children: [
          // Info Banner
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.blue.shade200),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: Colors.blue, size: 20),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Edit the $label content below and click Save to update',
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.blue.shade900,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 16),

          // Text Editor
          Expanded(
            child: TextField(
              controller: controller,
              maxLines: null,
              expands: true,
              textAlignVertical: TextAlignVertical.top,
              style: TextStyle(
                fontSize: isMobile ? 14 : 15,
                height: 1.5,
              ),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(color: Colors.grey.shade400),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: AppColors.accent, width: 2),
                ),
                filled: true,
                fillColor: Colors.grey.shade50,
                contentPadding: EdgeInsets.all(16),
              ),
            ),
          ),
          SizedBox(height: 16),

          // Action Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton.icon(
                onPressed: () {
                  final provider = context.read<SettingsProvider>();
                  final currentTab = _tabController.index;

                  // Reset to original content
                  if (currentTab == 0) {
                    controller.text = provider.privacyPolicy;
                  } else if (currentTab == 1) {
                    controller.text = provider.termsAndConditions;
                  } else {
                    controller.text = provider.helpAndSupport;
                  }

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Changes discarded'),
                      backgroundColor: Colors.orange,
                    ),
                  );
                },
                icon: Icon(Icons.refresh, size: 18),
                label: Text('Reset'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.orange,
                  side: BorderSide(color: Colors.orange),
                  padding: EdgeInsets.symmetric(
                    horizontal: isMobile ? 16 : 24,
                    vertical: isMobile ? 12 : 14,
                  ),
                ),
              ),
              SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: onSave,
                icon: Icon(Icons.save, size: 18),
                label: Text('Save Changes'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.accent,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(
                    horizontal: isMobile ? 16 : 24,
                    vertical: isMobile ? 12 : 14,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _saveContent(
      BuildContext context,
      int tabIndex,
      Future<bool> Function(String) updateFunction,
      ) async {
    final content = _controllers[tabIndex]!.text.trim();

    if (content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.warning, color: Colors.white),
              SizedBox(width: 8),
              Text('Content cannot be empty'),
            ],
          ),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // Show loader
    showLoader(context);

    final success = await updateFunction(content);

    // Hide loader
    if (mounted) Navigator.pop(context);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(
                success ? Icons.check_circle : Icons.error,
                color: Colors.white,
              ),
              SizedBox(width: 8),
              Text(success ? 'Content saved successfully' : 'Failed to save content'),
            ],
          ),
          backgroundColor: success ? AppColors.accent : AppColors.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      );
    }
  }
}