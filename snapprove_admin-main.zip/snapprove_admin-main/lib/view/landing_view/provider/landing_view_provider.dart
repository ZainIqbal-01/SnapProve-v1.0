import 'package:flutter/cupertino.dart';

class LandingViewProvider with ChangeNotifier {
  int index = 1;

  void updateIndex(int value) {
    index = value;
    notifyListeners();
  }
}