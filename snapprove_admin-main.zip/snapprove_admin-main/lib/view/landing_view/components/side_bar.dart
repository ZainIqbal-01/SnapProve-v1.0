import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import 'package:snap_prove_admin/view/auth/login_view.dart';
import '../provider/landing_view_provider.dart';

class SideBar extends StatelessWidget {
  final bool isMobile;
  final bool isTablet;

  const SideBar({
    super.key,
    this.isMobile = false,
    this.isTablet = false,
  });

  @override
  Widget build(BuildContext context) {
    final landingProvider = Provider.of<LandingViewProvider>(context, listen: true);

    // Mobile drawer - full width with close option
    if (isMobile) {
      return _buildMobileDrawer(context, landingProvider);
    }

    // Tablet - mini sidebar with icons only
    if (isTablet) {
      return _buildTabletSidebar(context, landingProvider);
    }

    // Desktop - full sidebar
    return _buildDesktopSidebar(context, landingProvider);
  }

  // Mobile Drawer
  Widget _buildMobileDrawer(BuildContext context, LandingViewProvider landingProvider) {
    return Container(
      width: 280,
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Admin Panel',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppColors.accent,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.close),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
          ),
          const Divider(),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(15.0),
              child: Column(
                children: [
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.dashboard,
                    label: 'Overview',
                    isSelected: landingProvider.index == 1,
                    onTap: () {
                      landingProvider.updateIndex(1);
                      Navigator.of(context).pop();
                    },
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.people,
                    label: 'Users',
                    isSelected: landingProvider.index == 2,
                    onTap: () {
                      landingProvider.updateIndex(2);
                      Navigator.of(context).pop();
                    },
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.local_offer,
                    label: 'Deals',
                    isSelected: landingProvider.index == 3,
                    onTap: () {
                      landingProvider.updateIndex(3);
                      Navigator.of(context).pop();
                    },
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.gavel,
                    label: 'Terms & Conditions',
                    isSelected: landingProvider.index == 4,
                    onTap: () {
                      landingProvider.updateIndex(4);
                      Navigator.of(context).pop();
                    },
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.settings,
                    label: 'Settings',
                    isSelected: landingProvider.index == 5,
                    onTap: () {
                      landingProvider.updateIndex(5);
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(20.0),
            child: _buildFullSidebarButton(
              context,
              icon: Icons.logout,
              label: 'Logout',
              isSelected: false,
              onTap: () {
                Navigator.of(context).pop();
                _showLogoutDialog(context);
              },
              color: Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  // Tablet Mini Sidebar
  Widget _buildTabletSidebar(BuildContext context, LandingViewProvider landingProvider) {
    return Container(
      width: 80,
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 20.0),
            child: Icon(
              Icons.admin_panel_settings,
              color: AppColors.accent,
              size: 32,
            ),
          ),
          const Divider(),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(vertical: 15.0),
              child: Column(
                children: [
                  _buildMiniSidebarButton(
                    context,
                    icon: Icons.dashboard,
                    tooltip: 'Overview',
                    isSelected: landingProvider.index == 1,
                    onTap: () => landingProvider.updateIndex(1),
                  ),
                  SizedBox(height: 10),
                  _buildMiniSidebarButton(
                    context,
                    icon: Icons.people,
                    tooltip: 'Users',
                    isSelected: landingProvider.index == 2,
                    onTap: () => landingProvider.updateIndex(2),
                  ),
                  SizedBox(height: 10),
                  _buildMiniSidebarButton(
                    context,
                    icon: Icons.local_offer,
                    tooltip: 'Deals',
                    isSelected: landingProvider.index == 3,
                    onTap: () => landingProvider.updateIndex(3),
                  ),
                  SizedBox(height: 10),
                  _buildMiniSidebarButton(
                    context,
                    icon: Icons.gavel,
                    tooltip: 'Terms & Conditions',
                    isSelected: landingProvider.index == 4,
                    onTap: () => landingProvider.updateIndex(4),
                  ),
                  SizedBox(height: 10),
                  _buildMiniSidebarButton(
                    context,
                    icon: Icons.settings,
                    tooltip: 'Settings',
                    isSelected: landingProvider.index == 5,
                    onTap: () => landingProvider.updateIndex(5),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 20.0),
            child: _buildMiniSidebarButton(
              context,
              icon: Icons.logout,
              tooltip: 'Logout',
              isSelected: false,
              onTap: () => _showLogoutDialog(context),
              color: Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  // Desktop Full Sidebar
  Widget _buildDesktopSidebar(BuildContext context, LandingViewProvider landingProvider) {
    return SingleChildScrollView(
      child: Container(
        width: 250,
        color: Colors.white,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(30.0),
              child: Text(
                'Admin Panel',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppColors.accent,
                ),
              ),
            ),
            const Divider(),
            Padding(
              padding: EdgeInsets.all(15.0),
              child: Column(
                children: [
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.dashboard,
                    label: 'Overview',
                    isSelected: landingProvider.index == 1,
                    onTap: () => landingProvider.updateIndex(1),
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.people,
                    label: 'Users',
                    isSelected: landingProvider.index == 2,
                    onTap: () => landingProvider.updateIndex(2),
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.local_offer,
                    label: 'Deals',
                    isSelected: landingProvider.index == 3,
                    onTap: () => landingProvider.updateIndex(3),
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.gavel,
                    label: 'Terms & Conditions',
                    isSelected: landingProvider.index == 4,
                    onTap: () => landingProvider.updateIndex(4),
                  ),
                  SizedBox(height: 10),
                  _buildFullSidebarButton(
                    context,
                    icon: Icons.settings,
                    label: 'Settings',
                    isSelected: landingProvider.index == 5,
                    onTap: () => landingProvider.updateIndex(5),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(20.0),
              child: _buildFullSidebarButton(
                context,
                icon: Icons.logout,
                label: 'Logout',
                isSelected: false,
                onTap: () => _showLogoutDialog(context),
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Full sidebar button (Desktop & Mobile)
  Widget _buildFullSidebarButton(
      BuildContext context, {
        required IconData icon,
        required String label,
        required bool isSelected,
        required VoidCallback onTap,
        Color? color,
      }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: isSelected ? Color(0xffF8FAFC) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: color ?? (isSelected ? AppColors.accent : Colors.grey),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Text(
                label,
                style: isSelected
                    ? TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: color ?? AppColors.accent,
                )
                    : TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: color ?? Colors.grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Mini sidebar button (Tablet)
  Widget _buildMiniSidebarButton(
      BuildContext context, {
        required IconData icon,
        required String tooltip,
        required bool isSelected,
        required VoidCallback onTap,
        Color? color,
      }) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.all(12.0),
          margin: EdgeInsets.symmetric(horizontal: 8.0),
          decoration: BoxDecoration(
            color: isSelected ? Color(0xffF8FAFC) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: color ?? (isSelected ? AppColors.accent : Colors.grey),
            size: 24,
          ),
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Logout'),
          content: Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text(
                'Logout',
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () async {
                Navigator.of(context).pop(); // Close dialog
                await _performLogout(context);
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _performLogout(BuildContext context) async {
    try {
      // Sign out from Firebase
      await FirebaseAuth.instance.signOut();

      // Navigate to login screen and clear all previous routes
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (context) => const LoginView(),
          ),
              (route) => false,
        );
      }

    } catch (e) {
      // Handle logout error
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.error, color: Colors.white),
                SizedBox(width: 8),
                Text('Failed to logout: ${e.toString()}'),
              ],
            ),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        );
      }
    }
  }
}