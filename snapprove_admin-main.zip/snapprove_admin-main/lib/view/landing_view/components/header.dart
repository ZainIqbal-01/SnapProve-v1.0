import 'package:flutter/material.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';

import '../../../common/utils/textStyles.dart';

class Header extends StatefulWidget {
  final String title;
  final String subtitle;
  final bool showMenuButton;

  const Header({
    super.key,
    required this.title,
    required this.subtitle,
    this.showMenuButton = false,
  });

  @override
  State<Header> createState() => _HeaderState();
}

class _HeaderState extends State<Header> {
  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Card(
      elevation: 0,
      color: Colors.white,
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: isMobile ? 16.0 : (isTablet ? 24.0 : 32.0),
          vertical: isMobile ? 12.0 : 16.0,
        ),
        child: Row(
          children: [
            // Menu button for mobile
            if (widget.showMenuButton) ...[
              IconButton(
                icon: Icon(Icons.menu),
                onPressed: () {
                  Scaffold.of(context).openDrawer();
                },
              ),
              SizedBox(width: 8),
            ],
            // Title and subtitle
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title,
                    style: isMobile
                        ? AppTextStylesInter.label24700B.copyWith(fontSize: 20)
                        : AppTextStylesInter.label24700B,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 2),
                  Text(
                    widget.subtitle,
                    style: isMobile
                        ? AppTextStylesInter.label12400BTC.copyWith(fontSize: 11)
                        : AppTextStylesInter.label12400BTC,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),



          ],
        ),
      ),
    );
  }
}