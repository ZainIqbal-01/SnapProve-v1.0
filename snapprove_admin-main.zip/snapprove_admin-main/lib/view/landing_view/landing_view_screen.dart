import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/view/landing_view/provider/landing_view_provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';

import '../deals/view/deal_view.dart';
import '../overview/view/overview_view.dart';
import '../terms_and_conditions/view/terms&conditions_view.dart';
import '../users/view/users_view.dart';
import '../settings/view/settings_view.dart';
import 'components/header.dart';
import 'components/side_bar.dart';

class LandingView extends StatelessWidget {
  const LandingView({super.key});

  @override
  Widget build(BuildContext context) {
    final isMobileView = Responsive.isMobile(context);
    final isTabletView = Responsive.isTablet(context);

    return Scaffold(
      backgroundColor: Color(0xffF8FAFC),
      // Mobile drawer
      drawer: isMobileView
          ? Drawer(
        child: SideBar(isMobile: true),
      )
          : null,
      body: Consumer<LandingViewProvider>(
        builder: (context, lvp, child) {
          // Get title and subtitle based on current index
          String title;
          String subtitle;

          switch (lvp.index) {
            case 1:
              title = 'Overview';
              subtitle = 'Detailed information about your store';
              break;
            case 2:
              title = 'Users';
              subtitle = 'Detailed information about users';
              break;
            case 3:
              title = 'Deals';
              subtitle = 'Detailed information about deals';
              break;
            case 4:
              title = 'Terms & Conditions';
              subtitle = 'Manage agreement terms for different types';
              break;
            case 5:
              title = 'Settings';
              subtitle = 'Configure your application settings';
              break;
            default:
              title = 'Overview';
              subtitle = 'Detailed information about your store';
          }

          // Mobile Layout
          if (isMobileView) {
            return Column(
              children: [
                Header(
                  title: title,
                  subtitle: subtitle,
                  showMenuButton: true,
                ),
                Expanded(
                  child: _getCurrentScreen(lvp.index),
                ),
              ],
            );
          }

          // Tablet Layout - Collapsible Sidebar
          if (isTabletView) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SideBar(isTablet: true),
                Expanded(
                  child: Column(
                    children: [
                      Header(
                        title: title,
                        subtitle: subtitle,
                      ),
                      Expanded(
                        child: _getCurrentScreen(lvp.index),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }

          // Web/Desktop Layout - Full Sidebar
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SideBar(),
              Expanded(
                child: Column(
                  children: [
                    Header(
                      title: title,
                      subtitle: subtitle,
                    ),
                    Expanded(
                      child: _getCurrentScreen(lvp.index),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _getCurrentScreen(int index) {
    switch (index) {
      case 1:
        return Overview();
      case 2:
        return UsersView();
      case 3:
        return DealsView();
      case 4:
        return TermsConditionsView();
      case 5:
        return SettingsView();
      default:
        return Overview();
    }
  }
}

