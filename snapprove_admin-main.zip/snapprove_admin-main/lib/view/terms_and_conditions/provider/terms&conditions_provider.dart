import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

/// Mirrors the shape stored in Firestore and displayed in the user app.
class TermsData {
  String title;
  String version;
  String introduction;
  List<String>? terms;
  DateTime? lastUpdated;

  TermsData({
    this.title = '',
    this.version = '1.0',
    this.introduction = '',
    this.terms ,
    this.lastUpdated,
  });

  /// Build from a Firestore document snapshot's data map.
  factory TermsData.fromMap(Map<String, dynamic> map) {
    return TermsData(
      title: map['title'] ?? '',
      version: map['version'] ?? '1.0',
      introduction: map['introduction'] ?? '',
      terms: (map['terms'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      lastUpdated: (map['updatedAt'] as Timestamp?)?.toDate(),
    );
  }

  /// Serialise for Firestore (excludes updatedAt — that is set server-side).
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'version': version,
      'introduction': introduction,
      'terms': terms,
    };
  }
}

class TermsConditionsProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Ordered list of document keys — order is preserved in the tab bar.
  static const List<String> keys = [
    'goods purchase',
    'freelance',
    'services',
    'loan',
    'rental',
    'custom',
  ];

  /// Current structured data for every key.
  final Map<String, TermsData> _termsData = {
    'goods purchase': TermsData(),
    'freelance': TermsData(),
    'services': TermsData(),
    'loan': TermsData(),
    'rental': TermsData(),
    'custom': TermsData(),
  };

  bool _isLoading = false;
  int _currentTab = 0;

  Map<String, TermsData> get termsData => _termsData;
  bool get isLoading => _isLoading;
  int get currentTab => _currentTab;

  void setCurrentTab(int index) {
    _currentTab = index;
    notifyListeners();
  }

  TermsData getTermsData(String key) => _termsData[key] ?? TermsData();

  // ── Firestore ─────────────────────────────────────────────────────────────

  Future<void> fetchAllTerms() async {
    _isLoading = true;
    notifyListeners();

    try {
      for (final key in keys) {
        final doc =
        await _firestore.collection('terms_and_conditions').doc(key).get();
        if (doc.exists && doc.data() != null) {
          _termsData[key] = TermsData.fromMap(doc.data()!);
        }
      }
    } catch (e) {
      debugPrint('Error fetching terms: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Save one document.  Returns true on success.
  Future<bool> updateTerms(String key, TermsData data) async {
    try {
      final map = data.toMap();
      map['updatedAt'] = FieldValue.serverTimestamp();

      await _firestore
          .collection('terms_and_conditions')
          .doc(key)
          .set(map, SetOptions(merge: true));

      // Refresh local copy with server timestamp
      final updated =
      await _firestore.collection('terms_and_conditions').doc(key).get();
      if (updated.exists) {
        _termsData[key] = TermsData.fromMap(updated.data()!);
      }

      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Error updating terms for $key: $e');
      return false;
    }
  }
}