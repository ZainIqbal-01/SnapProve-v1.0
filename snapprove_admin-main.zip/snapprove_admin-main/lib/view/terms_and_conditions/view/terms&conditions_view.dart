import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';

import '../../../common/custom_widgets/loader.dart';
import '../provider/terms&conditions_provider.dart';

class TermsConditionsView extends StatefulWidget {
  const TermsConditionsView({super.key});

  @override
  State<TermsConditionsView> createState() => _TermsConditionsViewState();
}

class _TermsConditionsViewState extends State<TermsConditionsView>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // ── per-tab editing state ─────────────────────────────────────────────────
  final Map<String, TextEditingController> _titleControllers = {};
  final Map<String, TextEditingController> _versionControllers = {};
  final Map<String, TextEditingController> _introControllers = {};
  final Map<String, List<TextEditingController>> _termControllers = {};

  /// Whether we're showing the preview pane (used on mobile/tablet toggle).
  bool _showPreview = false;

  // ── static meta ───────────────────────────────────────────────────────────
  static const Map<String, String> _tabLabels = {
    'goods purchase': 'Goods Purchase',
    'freelance': 'Freelance',
    'services': 'Services',
    'loan': 'Loan',
    'rental': 'Rental',
    'custom': 'Custom',
  };

  static const Map<String, IconData> _tabIcons = {
    'goods purchase': Icons.shopping_cart_outlined,
    'freelance': Icons.work_outline,
    'services': Icons.room_service_outlined,
    'loan': Icons.account_balance_outlined,
    'rental': Icons.home_outlined,
    'custom': Icons.edit_note_outlined,
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);

    // Init empty controllers for every key so nothing is null before fetch.
    for (final key in TermsConditionsProvider.keys) {
      _titleControllers[key] = TextEditingController();
      _versionControllers[key] = TextEditingController(text: '1.0');
      _introControllers[key] = TextEditingController();
      _termControllers[key] = [];
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<TermsConditionsProvider>().fetchAllTerms().then((_) {
        if (mounted) _syncControllersFromProvider();
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _titleControllers.values.forEach((c) => c.dispose());
    _versionControllers.values.forEach((c) => c.dispose());
    _introControllers.values.forEach((c) => c.dispose());
    _termControllers.values.forEach((list) => list.forEach((c) => c.dispose()));
    super.dispose();
  }

  // ── helpers ───────────────────────────────────────────────────────────────

  /// Push provider data → text controllers (called once after initial fetch).
  void _syncControllersFromProvider() {
    final provider = context.read<TermsConditionsProvider>();
    for (final key in TermsConditionsProvider.keys) {
      final data = provider.getTermsData(key);
      _titleControllers[key]!.text = data.title;
      _versionControllers[key]!.text = data.version;
      _introControllers[key]!.text = data.introduction;
      _rebuildTermControllers(key, data.terms ?? []);
    }
    setState(() {});
  }

  /// Replace the term-item controllers for a given key with fresh ones.
  void _rebuildTermControllers(String key, List<String> terms) {
    (_termControllers[key] ?? []).forEach((c) => c.dispose());
    _termControllers[key] =
        terms.map((t) => TextEditingController(text: t)).toList();
  }

  /// Read current term strings out of controllers.
  List<String> _currentTerms(String key) =>
      (_termControllers[key] ?? []).map((c) => c.text).toList();

  /// Get the active key based on tab index.
  String _activeKey() => TermsConditionsProvider.keys[_tabController.index];

  // ── build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Consumer<TermsConditionsProvider>(
      builder: (context, provider, child) {
        return Padding(
          padding: EdgeInsets.all(isMobile ? 12 : (isTablet ? 16 : 20)),
          child: Column(
            children: [
              // ── Header ──────────────────────────────────────────────────
              // Card(
              //   color: AppColors.whiteFFFFFF,
              //   elevation: 2,
              //   shape:
              //   RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              //   child: Container(
              //     width: double.infinity,
              //     padding: EdgeInsets.all(isMobile ? 16 : 20),
              //     child: Row(
              //       children: [
              //         Icon(Icons.gavel, color: AppColors.secondary, size: 28),
              //         const SizedBox(width: 12),
              //         Expanded(
              //           child: Column(
              //             crossAxisAlignment: CrossAxisAlignment.start,
              //             children: [
              //               Text(
              //                 'Terms & Conditions',
              //                 style: TextStyle(
              //                   fontSize: isMobile ? 20 : 24,
              //                   fontWeight: FontWeight.bold,
              //                 ),
              //               ),
              //               const SizedBox(height: 4),
              //               Text(
              //                 'Manage terms for different agreement types',
              //                 style: TextStyle(
              //                   fontSize: isMobile ? 13 : 14,
              //                   color: Colors.grey.shade600,
              //                 ),
              //               ),
              //             ],
              //           ),
              //         ),
              //       ],
              //     ),
              //   ),
              // ),
              // const SizedBox(height: 16),

              // ── Tab bar ─────────────────────────────────────────────────
              Card(
                color: AppColors.whiteFFFFFF,
                elevation: 2,
                shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border(
                      bottom:
                      BorderSide(color: Colors.grey.shade200, width: 1),
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      topRight: Radius.circular(12),
                    ),
                  ),
                  child: TabBar(
                    controller: _tabController,
                    labelColor: AppColors.accent,
                    unselectedLabelColor: Colors.grey.shade600,
                    indicatorColor: AppColors.accent,
                    indicatorWeight: 3,
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: isMobile ? 12 : 13,
                    ),
                    isScrollable: true,
                    onTap: (_) => setState(() {
                      _showPreview = false;
                    }),
                    tabs: TermsConditionsProvider.keys.map((key) {
                      return Tab(
                        icon: Icon(_tabIcons[key],
                            size: isMobile ? 18 : 20),
                        text: _tabLabels[key],
                      );
                    }).toList(),
                  ),
                ),
              ),

              // ── Body ────────────────────────────────────────────────────
              Expanded(
                child: provider.isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : TabBarView(
                  controller: _tabController,
                  children: TermsConditionsProvider.keys.map((key) {
                    // Desktop: side-by-side editor + preview.
                    // Mobile / Tablet: toggle between them.
                    if (!isMobile && !isTablet) {
                      return Row(
                        children: [
                          Expanded(
                              child: _buildEditor(context, key, isMobile)),
                          const SizedBox(width: 16),
                          Expanded(
                              child: _buildPreview(context, key, isMobile)),
                        ],
                      );
                    }
                    // Mobile / Tablet: single column with toggle.
                    return Column(
                      children: [
                        _buildToggleRow(isMobile),
                        Expanded(
                          child: _showPreview
                              ? _buildPreview(context, key, isMobile)
                              : _buildEditor(context, key, isMobile),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── toggle row (mobile / tablet) ─────────────────────────────────────────
  Widget _buildToggleRow(bool isMobile) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 8),
      child: Row(
        children: [
          Expanded(
            child: _buildToggleButton(
              label: 'Editor',
              icon: Icons.edit_outlined,
              isActive: !_showPreview,
              onTap: () => setState(() => _showPreview = false),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildToggleButton(
              label: 'Preview',
              icon: Icons.visibility_outlined,
              isActive: _showPreview,
              onTap: () => setState(() => _showPreview = true),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleButton({
    required String label,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isActive ? AppColors.accent.withOpacity(0.1) : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isActive ? AppColors.accent : Colors.grey.shade300,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18, color: isActive ? AppColors.accent : Colors.grey.shade600),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: isActive ? AppColors.accent : Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── EDITOR ────────────────────────────────────────────────────────────────
  Widget _buildEditor(BuildContext context, String key, bool isMobile) {
    final terms = _termControllers[key] ?? [];

    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SingleChildScrollView(
        padding: EdgeInsets.all(isMobile ? 14 : 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── section label ───────────────────────────────────────────
            _sectionLabel('Title & Version'),
            const SizedBox(height: 12),

            // Title
            _fieldLabel('Title'),
            _textField(
              controller: _titleControllers[key]!,
              hint: 'e.g. Goods Purchase Terms',
            ),
            const SizedBox(height: 12),

            // Version
            _fieldLabel('Version'),
            _textField(
              controller: _versionControllers[key]!,
              hint: 'e.g. 1.0',
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 20),

            // ── Introduction ─────────────────────────────────────────────
            _sectionLabel('Introduction'),
            const SizedBox(height: 12),
            _textField(
              controller: _introControllers[key]!,
              hint: 'Write a short introduction paragraph...',
              maxLines: 4,
            ),
            const SizedBox(height: 20),

            // ── Terms list ───────────────────────────────────────────────
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _sectionLabel('Terms'),
                InkWell(
                  onTap: () => setState(() {
                    (_termControllers[key] ??= [])
                        .add(TextEditingController());
                  }),
                  borderRadius: BorderRadius.circular(6),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: AppColors.accent.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add, color: AppColors.accent, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          'Add Term',
                          style: TextStyle(
                            fontSize: 13,
                            color: AppColors.accent,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // each term row
            ...terms.asMap().entries.map((entry) {
              final idx = entry.key;
              final ctrl = entry.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // number badge
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Center(
                        child: Text(
                          '${idx + 1}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: AppColors.accent,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),

                    // text field
                    Expanded(
                      child: TextField(
                        controller: ctrl,
                        maxLines: 2,
                        style: const TextStyle(fontSize: 14, height: 1.5),
                        onChanged: (_) => setState(() {}),
                        decoration: InputDecoration(
                          hintText: 'Term ${idx + 1} description...',
                          hintStyle: TextStyle(color: Colors.grey.shade400),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: AppColors.accent, width: 2),
                          ),
                          filled: true,
                          fillColor: Colors.grey.shade50,
                          contentPadding: const EdgeInsets.all(12),
                          // move-up / move-down / delete icons inside suffix
                          suffixIcon: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (idx > 0)
                                IconButton(
                                  iconSize: 18,
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(),
                                  icon: const Icon(Icons.arrow_upward, size: 16),
                                  color: Colors.grey.shade500,
                                  onPressed: () => setState(() {
                                    final list = _termControllers[key]!;
                                    final tmp = list[idx];
                                    list[idx] = list[idx - 1];
                                    list[idx - 1] = tmp;
                                  }),
                                ),
                              if (idx < terms.length - 1)
                                IconButton(
                                  iconSize: 18,
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(),
                                  icon: const Icon(Icons.arrow_downward, size: 16),
                                  color: Colors.grey.shade500,
                                  onPressed: () => setState(() {
                                    final list = _termControllers[key]!;
                                    final tmp = list[idx];
                                    list[idx] = list[idx + 1];
                                    list[idx + 1] = tmp;
                                  }),
                                ),
                              IconButton(
                                iconSize: 18,
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(),
                                icon: const Icon(Icons.close, size: 16),
                                color: Colors.red.shade400,
                                onPressed: () => setState(() {
                                  ctrl.dispose();
                                  _termControllers[key]!.removeAt(idx);
                                }),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),

            const SizedBox(height: 24),

            // ── Action Buttons ─────────────────────────────────────────
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Reset
                OutlinedButton.icon(
                  onPressed: () {
                    final provider = context.read<TermsConditionsProvider>();
                    final data = provider.getTermsData(key);
                    _titleControllers[key]!.text = data.title;
                    _versionControllers[key]!.text = data.version;
                    _introControllers[key]!.text = data.introduction;
                    _rebuildTermControllers(key, data.terms ?? []);
                    setState(() {});
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Changes discarded'),
                        backgroundColor: Colors.orange,
                      ),
                    );
                  },
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('Reset'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.orange,
                    side: const BorderSide(color: Colors.orange),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  ),
                ),
                const SizedBox(width: 12),

                // Save
                ElevatedButton.icon(
                  onPressed: () => _saveContent(context, key),
                  icon: const Icon(Icons.save, size: 18),
                  label: const Text('Save Changes'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── PREVIEW (mirrors the user app exactly) ───────────────────────────────
  Widget _buildPreview(BuildContext context, String key, bool isMobile) {
    final title = _titleControllers[key]!.text;
    final version = _versionControllers[key]!.text;
    final intro = _introControllers[key]!.text;
    final terms = _currentTerms(key);

    // Grab lastUpdated from provider (server timestamp of last save).
    final provider = context.read<TermsConditionsProvider>();
    final lastUpdated = provider.getTermsData(key).lastUpdated;

    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: SingleChildScrollView(
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Preview badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.purple.shade50,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: Colors.purple.shade200),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.visibility_outlined, color: Colors.purple, size: 16),
                  const SizedBox(width: 6),
                  const Text(
                    'Live Preview',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.purple,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Divider(color: Colors.grey),
            const SizedBox(height: 20),

            // ── Title ─────────────────────────────────────────────────
            Text(
              title.isNotEmpty ? title : 'Title',
              style: TextStyle(
                fontSize: isMobile ? 22 : 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),

            // ── Version badge + Last updated ──────────────────────────
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    'Version $version',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.accent,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'Last updated: ${lastUpdated != null ? _formatDate(lastUpdated) : 'Not saved yet'}',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 20),

            // ── Introduction ──────────────────────────────────────────
            if (intro.isNotEmpty) ...[
              Text(
                intro,
                style: TextStyle(
                  fontSize: isMobile ? 15 : 16,
                  height: 1.6,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 20),
            ],

            // ── Numbered terms ────────────────────────────────────────
            ...terms.asMap().entries.map((entry) {
              final idx = entry.key;
              final term = entry.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: AppColors.accent.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Center(
                        child: Text(
                          '${idx + 1}',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppColors.accent,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(
                          term,
                          style: TextStyle(
                            fontSize: isMobile ? 14 : 15,
                            height: 1.5,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),

            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 14),

            // ── Footer note (same as user app) ────────────────────────
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.info_outline, color: Colors.blue, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'By proceeding with your submission, you confirm that you have read, understood, and agree to these terms and conditions.',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.blue.shade800,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── small helpers ─────────────────────────────────────────────────────────

  Widget _sectionLabel(String text) => Text(
    text,
    style: TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w700,
      color: AppColors.secondary,
    ),
  );

  Widget _fieldLabel(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(
      text,
      style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
    ),
  );

  Widget _textField({
    required TextEditingController controller,
    required String hint,
    int maxLines = 1,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      style: const TextStyle(fontSize: 14, height: 1.5),
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.grey.shade400),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: AppColors.accent, width: 2),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
        contentPadding: const EdgeInsets.all(12),
      ),
    );
  }

  String _formatDate(DateTime date) =>
      DateFormat('d/M/yyyy').format(date);

  // ── save ──────────────────────────────────────────────────────────────────
  Future<void> _saveContent(BuildContext context, String key) async {
    final title = _titleControllers[key]!.text.trim();
    final version = _versionControllers[key]!.text.trim();
    final intro = _introControllers[key]!.text.trim();
    final terms = _currentTerms(key).map((t) => t.trim()).toList();

    // Basic validation
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        _warningSnack('Title cannot be empty'),
      );
      return;
    }
    if (terms.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        _warningSnack('Add at least one term'),
      );
      return;
    }

    // Show loader
    showLoader(context);

    final provider = context.read<TermsConditionsProvider>();
    final data = TermsData(
      title: title,
      version: version.isNotEmpty ? version : '1.0',
      introduction: intro,
      terms: terms,
    );

    final success = await provider.updateTerms(key, data);

    // Hide loader
    if (mounted) Navigator.pop(context);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(
                success ? Icons.check_circle : Icons.error,
                color: Colors.white,
              ),
              const SizedBox(width: 8),
              Text(
                success
                    ? '${_tabLabels[key]} saved successfully'
                    : 'Failed to save ${_tabLabels[key]}',
              ),
            ],
          ),
          backgroundColor: success ? AppColors.accent : AppColors.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      );
    }
  }

  SnackBar _warningSnack(String msg) => SnackBar(
    content: Row(
      children: [
        const Icon(Icons.warning, color: Colors.white),
        const SizedBox(width: 8),
        Text(msg),
      ],
    ),
    backgroundColor: Colors.orange,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
  );
}