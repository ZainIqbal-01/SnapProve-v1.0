import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import 'package:snap_prove_admin/view/deals/view/deal_details_view.dart';
import '../../../common/custom_widgets/loader.dart';
import '../model/deal_model.dart';
import '../provider/deal_provider.dart';

class DealsView extends StatefulWidget {
  const DealsView({super.key});

  @override
  State<DealsView> createState() => _DealsViewState();
}

class _DealsViewState extends State<DealsView> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DealsProvider>().fetchDeals();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Consumer<DealsProvider>(
      builder: (context, provider, child) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // Search and Filter Section
              _buildSearchAndFilter(context, provider, isMobile, isTablet),

              // Deals List
              Expanded(
                child: provider.isLoading
                    ? Center(child: CircularProgressIndicator())
                    : provider.deals.isEmpty
                    ? _buildEmptyState()
                    : _buildDealsList(context, provider, isMobile, isTablet),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSearchAndFilter(BuildContext context, DealsProvider provider, bool isMobile, bool isTablet) {
    return Container(
      padding: EdgeInsets.all(isMobile ? 12 : (isTablet ? 16 : 20)),
      color: Colors.white,
      child: Column(
        children: [
          // Search Bar
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) => provider.searchDeals(value),
                  decoration: InputDecoration(
                    hintText: 'Search by title, party name, or deal ID...',
                    prefixIcon: Icon(Icons.search),
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        provider.searchDeals('');
                      },
                    )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.blue),
                    ),
                    filled: true,
                    fillColor: Colors.grey.shade50,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  ),
                ),
              ),
              if (!isMobile) ...[
                SizedBox(width: 16),
                _buildRefreshButton(provider),
              ],
            ],
          ),
          SizedBox(height: 12),

          // Deal Type Filter
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildFilterChip('All Types', 'all', provider, isMobile, isDealType: true),
                      SizedBox(width: 8),
                      _buildFilterChip('Goods Purchase', 'Goods Purchase', provider, isMobile, isDealType: true),
                      SizedBox(width: 8),
                      _buildFilterChip('Rental', 'Rental', provider, isMobile, isDealType: true),
                      SizedBox(width: 8),
                      _buildFilterChip('Services', 'Services', provider, isMobile, isDealType: true),
                      SizedBox(width: 8),
                      _buildFilterChip('Freelance', 'Freelance', provider, isMobile, isDealType: true),
                      SizedBox(width: 8),
                      _buildFilterChip('Loan', 'Loan agreement', provider, isMobile, isDealType: true),
                      SizedBox(width: 8),
                      _buildFilterChip('Custom', 'Custom', provider, isMobile, isDealType: true),
                    ],
                  ),
                ),
              ),
              if (isMobile) ...[
                SizedBox(width: 8),
                _buildRefreshButton(provider),
              ],
            ],
          ),
          SizedBox(height: 8),

          // Status Filter
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      _buildFilterChip('All Status', 'all', provider, isMobile, isDealType: false),
                      SizedBox(width: 8),
                      _buildFilterChip('Pending', 'pending', provider, isMobile, isDealType: false),
                      SizedBox(width: 8),
                      _buildFilterChip('Completed', 'completed', provider, isMobile, isDealType: false),
                      SizedBox(width: 8),
                      _buildFilterChip('Rejected', 'rejected', provider, isMobile, isDealType: false),
                    ],
                  ),
                ),
              ),

              if (!isMobile) Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '${provider.deals.length} deal(s) found',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: isMobile ? 12 : 14,
                  ),
                ),
              ),
            ],
          ),

          // Results count
          if (isMobile)...[
            SizedBox(
              height: 10,
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '${provider.deals.length} deal(s) found',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: isMobile ? 12 : 14,
                ),
              ),
            ),
          ]
        ],
      ),
    );
  }

  Widget _buildRefreshButton(DealsProvider provider) {
    return IconButton(
      icon: Icon(Icons.refresh),
      onPressed: () => provider.fetchDeals(),
      tooltip: 'Refresh',
      style: IconButton.styleFrom(
        backgroundColor: AppColors.accent.withValues(alpha: 0.2),
        foregroundColor: AppColors.accent,
      ),
    );
  }

  Widget _buildFilterChip(String label, String value, DealsProvider provider, bool isMobile, {required bool isDealType}) {
    final isSelected = isDealType
        ? provider.filterDealType == value
        : provider.filterStatus == value;

    return ChoiceChip(
      checkmarkColor: AppColors.whiteFFFFFF,
      label: Text(
        label,
        style: TextStyle(
          fontSize: isMobile ? 12 : 14,
          fontWeight: FontWeight.w600,
        ),
      ),
      selected: isSelected,
      onSelected: (selected) {
        if (isDealType) {
          provider.filterByDealType(value);
        } else {
          provider.filterByStatus(value);
        }
      },
      selectedColor: AppColors.secondary,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : Colors.grey.shade700,
      ),
      backgroundColor: Colors.grey.shade100,
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 8 : 12, vertical: 4),
    );
  }

  Widget _buildDealsList(BuildContext context, DealsProvider provider, bool isMobile, bool isTablet) {
    if (isMobile) {
      return _buildMobileDealsList(context, provider);
    } else if (isTablet) {
      return _buildTabletDealsList(context, provider);
    } else {
      return _buildDesktopDealsList(context, provider);
    }
  }

  // Mobile: Card-based list
  Widget _buildMobileDealsList(BuildContext context, DealsProvider provider) {
    return RefreshIndicator(
      onRefresh: () => provider.fetchDeals(),
      child: ListView.builder(
        padding: EdgeInsets.all(12),
        itemCount: provider.deals.length,
        itemBuilder: (context, index) {
          final deal = provider.deals[index];
          return _buildMobileDealCard(context, deal, provider);
        },
      ),
    );
  }

  Widget _buildMobileDealCard(BuildContext context, DealModel deal, DealsProvider provider) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => _navigateToDealDetail(context, deal),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with deal type and status
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getDealTypeColor(deal.dealType).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        deal.dealType,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _getDealTypeColor(deal.dealType),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  _buildStatusChip(deal.status, true),
                ],
              ),
              SizedBox(height: 12),

              // Deal title
              Text(
                deal.dealTitle,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 8),

              // Deal info
              Row(
                children: [
                  Icon(Icons.person_outline, size: 14, color: Colors.grey.shade600),
                  SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      deal.otherParty,
                      style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 4),
              Row(
                children: [
                  Icon(Icons.calendar_today, size: 14, color: Colors.grey.shade600),
                  SizedBox(width: 4),
                  Text(
                    _formatDate(deal.date),
                    style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                  ),
                ],
              ),
              if (deal.amount != null) ...[
                SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.attach_money, size: 14, color: Colors.grey.shade600),
                    Text(
                      '${deal.currency} ${_formatAmount(deal.amount!)}',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.secondary,
                      ),
                    ),
                  ],
                ),
              ],
              SizedBox(height: 12),

              // Action button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => _navigateToDealDetail(context, deal),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 8),
                  ),
                  child: Text('View Details', style: TextStyle(fontSize: 13)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Tablet: Grid view
  Widget _buildTabletDealsList(BuildContext context, DealsProvider provider) {
    return GridView.builder(
      padding: EdgeInsets.all(16),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.4,
      ),
      itemCount: provider.deals.length,
      itemBuilder: (context, index) {
        final deal = provider.deals[index];
        return _buildTabletDealCard(context, deal, provider);
      },
    );
  }

  Widget _buildTabletDealCard(BuildContext context, DealModel deal, DealsProvider provider) {
    return Card(
      elevation: 2,
      color: AppColors.whiteFFFFFF,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => _navigateToDealDetail(context, deal),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: _getDealTypeColor(deal.dealType).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        deal.dealType,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: _getDealTypeColor(deal.dealType),
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  _buildStatusChip(deal.status, false),
                ],
              ),
              SizedBox(height: 12),

              // Deal title
              Text(
                deal.dealTitle,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 8),

              // Deal info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.person_outline, size: 14, color: Colors.grey.shade600),
                        SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            deal.otherParty,
                            style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.calendar_today, size: 14, color: Colors.grey.shade600),
                        SizedBox(width: 4),
                        Text(
                          _formatDate(deal.date),
                          style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                    if (deal.amount != null) ...[
                      SizedBox(height: 4),
                      Text(
                        '${deal.currency} ${_formatAmount(deal.amount!)}',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: AppColors.secondary,
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              // Action button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => _navigateToDealDetail(context, deal),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 8),
                  ),
                  child: Text('View Details', style: TextStyle(fontSize: 13)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Desktop: List view with cards
  Widget _buildDesktopDealsList(BuildContext context, DealsProvider provider) {
    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: provider.deals.length,
      itemBuilder: (context, index) {
        final deal = provider.deals[index];

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 2,
          color: AppColors.whiteFFFFFF,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Deal type icon
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: _getDealTypeColor(deal.dealType).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    _getDealTypeIcon(deal.dealType),
                    color: _getDealTypeColor(deal.dealType),
                    size: 24,
                  ),
                ),

                const SizedBox(width: 16),

                // Deal info
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        deal.dealTitle,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'with ${deal.otherParty}',
                        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: _getDealTypeColor(deal.dealType).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              deal.dealType,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: _getDealTypeColor(deal.dealType),
                              ),
                            ),
                          ),
                          SizedBox(width: 8),
                          Icon(Icons.calendar_today, size: 12, color: Colors.grey.shade600),
                          SizedBox(width: 4),
                          Text(
                            _formatDate(deal.date),
                            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Amount
                if (deal.amount != null)
                  Expanded(
                    flex: 1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${deal.currency}',
                          style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                        ),
                        Text(
                          _formatAmount(deal.amount!),
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppColors.secondary,
                          ),
                        ),
                      ],
                    ),
                  ),

                const SizedBox(width: 16),

                // Status
                _buildStatusChip(deal.status, false),

                const SizedBox(width: 16),

                // Actions
                ElevatedButton(
                  onPressed: () => _navigateToDealDetail(context, deal),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('View', style: TextStyle(fontSize: 12)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.local_offer_outlined, size: 64, color: Colors.grey.shade400),
          SizedBox(height: 16),
          Text(
            'No deals found',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade600,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Try adjusting your search or filter',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip(String status, bool isMobile) {
    Color bgColor;
    Color textColor;
    String label;

    switch (status) {
      case 'completed':
        bgColor = Colors.green.shade50;
        textColor = Colors.green;
        label = 'Completed';
        break;
      case 'rejected':
        bgColor = Colors.red.shade50;
        textColor = Colors.red;
        label = 'Rejected';
        break;
      case 'pending':
      default:
        bgColor = Colors.orange.shade50;
        textColor = Colors.orange;
        label = 'Pending';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 8 : 10, vertical: isMobile ? 4 : 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: textColor.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: isMobile ? 10 : 11,
          color: textColor,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Color _getDealTypeColor(String dealType) {
    switch (dealType) {
      case 'Goods Purchase':
        return Colors.blue;
      case 'Rental':
        return Colors.purple;
      case 'Services':
        return Colors.orange;
      case 'Freelance':
        return Colors.teal;
      case 'Loan agreement':
        return Colors.red;
      case 'Custom':
        return Colors.indigo;
      default:
        return Colors.grey;
    }
  }

  IconData _getDealTypeIcon(String dealType) {
    switch (dealType) {
      case 'Goods Purchase':
        return Icons.shopping_cart;
      case 'Rental':
        return Icons.home;
      case 'Services':
        return Icons.build;
      case 'Freelance':
        return Icons.work;
      case 'Loan agreement':
        return Icons.account_balance;
      case 'Custom':
        return Icons.description;
      default:
        return Icons.local_offer;
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM dd, yyyy').format(date);
  }

  String _formatAmount(double amount) {
    final formatter = NumberFormat('#,##0.00');
    return formatter.format(amount);
  }

  void _navigateToDealDetail(BuildContext context, DealModel deal) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DealDetailView(dealId: deal.dealId),
      ),
    );
  }
}