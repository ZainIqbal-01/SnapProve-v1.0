import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:intl/intl.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../common/custom_widgets/loader.dart';
import '../model/deal_model.dart';
import '../provider/deal_provider.dart';

class DealDetailView extends StatefulWidget {
  final String dealId;

  const DealDetailView({super.key, required this.dealId});

  @override
  State<DealDetailView> createState() => _DealDetailViewState();
}

class _DealDetailViewState extends State<DealDetailView> {
  DealModel? _deal;
  bool _isLoading = true;
  Map<String, dynamic>? _currentUserData;
  Map<String, dynamic>? _otherUserData;

  @override
  void initState() {
    super.initState();
    _loadDealData();
  }

  Future<void> _loadDealData() async {
    setState(() => _isLoading = true);
    final provider = context.read<DealsProvider>();
    final deal = await provider.refreshDealData(widget.dealId);
    setState(() {
      _deal = deal ?? provider.getDealById(widget.dealId);
    });

    if (_deal != null) {
      await _loadUserData();
    }

    setState(() => _isLoading = false);
  }

  Future<void> _loadUserData() async {
    try {
      // Fetch current user (deal creator) data
      final currentUserDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(_deal!.userId)
          .get();

      if (currentUserDoc.exists) {
        _currentUserData = currentUserDoc.data();
      }

      // Fetch other party data if userId is available
      if (_deal!.otherPartyUserId.isNotEmpty) {
        final otherUserDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(_deal!.otherPartyUserId)
            .get();

        if (otherUserDoc.exists) {
          _otherUserData = otherUserDoc.data();
        }
      }

      setState(() {});
    } catch (e) {
      print('Error loading user data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Deal Details',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.black),
            onPressed: _loadDealData,
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _deal == null
          ? _buildErrorState()
          : isMobile
          ? _buildMobileLayout()
          : isTablet
          ? _buildTabletLayout()
          : _buildDesktopLayout(),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error_outline, size: 64, color: Colors.red),
          SizedBox(height: 16),
          Text('Deal not found', style: TextStyle(fontSize: 18)),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Go Back'),
          ),
        ],
      ),
    );
  }

  // Mobile Layout - Single column
  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(12),
      child: Column(
        children: [
          _buildOverviewCard(true),
          SizedBox(height: 12),
          _buildCurrentUserInfoCard(true),
          SizedBox(height: 12),
          _buildOtherPartyInfoCard(true),
          SizedBox(height: 12),
          _buildDealDetailsCard(true),
          SizedBox(height: 12),
          if (_deal!.typeSpecificData != null)
            _buildTypeSpecificDataCard(true),
          if (_deal!.typeSpecificData != null) SizedBox(height: 12),
          if (_deal!.evidence != null)
            _buildEvidenceCard(true),
        ],
      ),
    );
  }

  // Tablet Layout
  Widget _buildTabletLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _buildOverviewCard(false)),
              SizedBox(width: 16),
              Expanded(child: _buildDealDetailsCard(false)),
            ],
          ),
          SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: _buildCurrentUserInfoCard(false)),
              SizedBox(width: 16),
              Expanded(child: _buildOtherPartyInfoCard(false)),
            ],
          ),
          SizedBox(height: 16),
          if (_deal!.typeSpecificData != null) ...[
            _buildTypeSpecificDataCard(false),
            SizedBox(height: 16),
          ],
          if (_deal!.evidence != null) ...[
            _buildEvidenceCard(false),
          ],
        ],
      ),
    );
  }

  // Desktop Layout
  Widget _buildDesktopLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Left Column
          Expanded(
            flex: 4,
            child: Column(
              children: [
                _buildOverviewCard(false),
                SizedBox(height: 20),
                _buildCurrentUserInfoCard(false),
                SizedBox(height: 20),
                _buildOtherPartyInfoCard(false),
              ],
            ),
          ),
          SizedBox(width: 20),

          // Right Column
          Expanded(
            flex: 6,
            child: Column(
              children: [
                _buildDealDetailsCard(false),
                SizedBox(height: 20),
                if (_deal!.typeSpecificData != null) ...[
                  _buildTypeSpecificDataCard(false),
                  SizedBox(height: 20),
                ],
                if (_deal!.evidence != null)
                  _buildEvidenceCard(false),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewCard(bool isMobile) {
    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Deal Overview',
              style: TextStyle(
                fontSize: isMobile ? 18 : 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),

            // Deal ID
            _buildInfoRow(
              Icons.tag,
              'Deal ID',
              _deal!.dealId,
              isMobile,
            ),
            _buildDivider(),

            // Deal Type
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _getDealTypeColor(_deal!.dealType).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(_getDealTypeIcon(_deal!.dealType), size: 18, color: _getDealTypeColor(_deal!.dealType)),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Deal Type',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        _deal!.dealType,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            _buildDivider(),

            // Status
            _buildInfoRow(
              Icons.info_outline,
              'Status',
              '',
              isMobile,
              customValue: _buildStatusChip(_deal!.status),
            ),
            _buildDivider(),

            // Amount
            if (_deal!.amount != null) ...[
              _buildInfoRow(
                Icons.attach_money,
                'Amount',
                '${_deal!.currency} ${_formatAmount(_deal!.amount!)}',
                isMobile,
              ),
              _buildDivider(),
            ],

            // Created Date
            _buildInfoRow(
              Icons.calendar_today,
              'Created',
              _formatDate(_deal!.createdAt),
              isMobile,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentUserInfoCard(bool isMobile) {
    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.person, color: AppColors.secondary, size: 20),
                SizedBox(width: 8),
                Text(
                  'Deal Creator',
                  style: TextStyle(
                    fontSize: isMobile ? 18 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            if (_currentUserData != null) ...[
              _buildInfoRow(
                Icons.person,
                'Name',
                _currentUserData!['fullName'] ?? 'N/A',
                isMobile,
              ),
              _buildDivider(),

              _buildInfoRow(
                Icons.phone,
                'Phone',
                _currentUserData!['phoneNumber'] ?? 'N/A',
                isMobile,
              ),
              _buildDivider(),

              _buildInfoRow(
                Icons.email,
                'Email',
                _currentUserData!['email'] ?? 'N/A',
                isMobile,
              ),
              _buildDivider(),

              _buildInfoRow(
                Icons.credit_card,
                'CNIC',
                _currentUserData!['cnicNumber'] ?? 'N/A',
                isMobile,
              ),
            ] else ...[
              Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    'Loading user information...',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildOtherPartyInfoCard(bool isMobile) {
    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.people, color: AppColors.secondary, size: 20),
                SizedBox(width: 8),
                Text(
                  'Other Party',
                  style: TextStyle(
                    fontSize: isMobile ? 18 : 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            _buildInfoRow(
              Icons.person,
              'Name',
              _deal!.otherParty,
              isMobile,
            ),
            _buildDivider(),

            _buildInfoRow(
              Icons.phone,
              'Phone',
              _deal!.otherPartyPhone,
              isMobile,
            ),
            _buildDivider(),

            _buildInfoRow(
              Icons.email,
              'Email',
              _deal!.otherPartyEmail,
              isMobile,
            ),
            _buildDivider(),

            _buildInfoRow(
              Icons.credit_card,
              'CNIC',
              _deal!.otherPartyCnic,
              isMobile,
            ),

            // Show additional info from users collection if available
            if (_deal!.otherPartyUserId.isNotEmpty && _otherUserData != null) ...[
              _buildDivider(),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.green.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.verified_user, color: Colors.green, size: 18),
                    SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Registered User',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.green.shade700,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'This party has an account in the system',
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.green.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ] else if (_deal!.otherPartyUserId.isEmpty) ...[
              _buildDivider(),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.orange, size: 18),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Guest Party (Not registered)',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Colors.orange.shade700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDealDetailsCard(bool isMobile) {
    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Deal Details',
              style: TextStyle(
                fontSize: isMobile ? 18 : 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),

            // Title
            _buildInfoRow(
              Icons.title,
              'Title',
              _deal!.dealTitle,
              isMobile,
            ),
            _buildDivider(),

            // Description
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.secondary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.description, size: 18, color: AppColors.secondary),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Description',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        _deal!.description,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            _buildDivider(),

            // Date
            _buildInfoRow(
              Icons.event,
              'Deal Date',
              _formatDate(_deal!.date),
              isMobile,
            ),

            // Due Date
            if (_deal!.dueDate != null) ...[
              _buildDivider(),
              _buildInfoRow(
                Icons.event_available,
                'Due Date',
                _formatDate(_deal!.dueDate!),
                isMobile,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTypeSpecificDataCard(bool isMobile) {
    final typeData = _deal!.typeSpecificData!;

    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${_deal!.dealType} Details',
              style: TextStyle(
                fontSize: isMobile ? 18 : 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),

            // Display all type-specific fields
            ...typeData.entries.map((entry) {
              final key = _formatFieldName(entry.key);
              final value = _formatFieldValue(entry.value);

              return Column(
                children: [
                  _buildInfoRow(
                    Icons.info_outline,
                    key,
                    value,
                    isMobile,
                  ),
                  if (entry.key != typeData.keys.last) _buildDivider(),
                ],
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildEvidenceCard(bool isMobile) {
    final evidence = _deal!.evidence!;

    return Card(
      color: AppColors.whiteFFFFFF,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(isMobile ? 16 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Evidence & Attachments',
              style: TextStyle(
                fontSize: isMobile ? 18 : 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),

            // Recorded Video
            if (evidence.recordedVideoUrl != null) ...[
              _buildEvidenceSection(
                'Proof Video',
                Icons.videocam,
                [evidence.recordedVideoUrl!],
                'video',
                isMobile,
              ),
              SizedBox(height: 16),
            ],

            // Images
            if (evidence.images.isNotEmpty) ...[
              _buildEvidenceSection(
                'Images',
                Icons.image,
                evidence.images,
                'image',
                isMobile,
              ),
              SizedBox(height: 16),
            ],

            // Invoices
            if (evidence.invoices.isNotEmpty) ...[
              _buildEvidenceSection(
                'Invoices',
                Icons.receipt,
                evidence.invoices,
                'invoice',
                isMobile,
              ),
              SizedBox(height: 16),
            ],

            // Payments
            if (evidence.payments.isNotEmpty) ...[
              _buildEvidenceSection(
                'Payment Proofs',
                Icons.payment,
                evidence.payments,
                'payment',
                isMobile,
              ),
              SizedBox(height: 16),
            ],

            // Others
            if (evidence.others.isNotEmpty) ...[
              _buildEvidenceSection(
                'Other Documents',
                Icons.attach_file,
                evidence.others,
                'other',
                isMobile,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildEvidenceSection(String title, IconData icon, List<String> files, String type, bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 18, color: AppColors.secondary),
            SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade700,
              ),
            ),
            SizedBox(width: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: AppColors.secondary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '${files.length}',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.secondary,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 12),

        // Display files
        if (type == 'image' || type == 'invoice' || type == 'payment')
          _buildImageGrid(files, isMobile)
        else
          _buildFileList(files, type, isMobile),
      ],
    );
  }

  Widget _buildImageGrid(List<String> imageUrls, bool isMobile) {
    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isMobile ? 2 : 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1,
      ),
      itemCount: imageUrls.length,
      itemBuilder: (context, index) {
        return InkWell(
          onTap: () => _downloadFile(imageUrls[index]),
          borderRadius: BorderRadius.circular(8),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    imageUrls[index],
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: Colors.grey.shade100,
                        child: Icon(Icons.broken_image, color: Colors.grey),
                      );
                    },
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Container(
                        color: Colors.grey.shade100,
                        child: Center(child: CircularProgressIndicator()),
                      );
                    },
                  ),
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      padding: EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Icon(Icons.download, color: Colors.white, size: 16),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildFileList(List<String> fileUrls, String type, bool isMobile) {
    return Column(
      children: fileUrls.map((url) {
        final fileName = _getFileNameFromUrl(url);
        final fileExtension = _getFileExtension(url);

        return Container(
          margin: EdgeInsets.only(bottom: 8),
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.grey.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _getFileColor(fileExtension).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(
                  _getFileIcon(fileExtension),
                  color: _getFileColor(fileExtension),
                  size: 20,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fileName,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 2),
                    Text(
                      fileExtension.toUpperCase(),
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(Icons.download, size: 20),
                onPressed: () => _downloadFile(url),
                tooltip: 'Download',
                color: AppColors.accent,
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, bool isMobile, {Widget? customValue}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.secondary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 18, color: AppColors.secondary),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 4),
                customValue ?? Text(
                  value,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Divider(color: Colors.grey.shade200, height: 1),
    );
  }

  Widget _buildStatusChip(String status) {
    Color bgColor;
    Color textColor;
    String label;
    IconData icon;

    switch (status) {
      case 'completed':
        bgColor = Colors.green.shade50;
        textColor = Colors.green;
        label = 'Completed';
        icon = Icons.check_circle;
        break;
      case 'rejected':
        bgColor = Colors.red.shade50;
        textColor = Colors.red;
        label = 'Rejected';
        icon = Icons.cancel;
        break;
      case 'pending':
      default:
        bgColor = Colors.orange.shade50;
        textColor = Colors.orange;
        label = 'Pending';
        icon = Icons.schedule;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: textColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: textColor, size: 14),
          SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: textColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Color _getDealTypeColor(String dealType) {
    switch (dealType) {
      case 'Goods Purchase':
        return Colors.blue;
      case 'Rental':
        return Colors.purple;
      case 'Services':
        return Colors.orange;
      case 'Freelance':
        return Colors.teal;
      case 'Loan agreement':
        return Colors.red;
      case 'Custom':
        return Colors.indigo;
      default:
        return Colors.grey;
    }
  }

  IconData _getDealTypeIcon(String dealType) {
    switch (dealType) {
      case 'Goods Purchase':
        return Icons.shopping_cart;
      case 'Rental':
        return Icons.home;
      case 'Services':
        return Icons.build;
      case 'Freelance':
        return Icons.work;
      case 'Loan agreement':
        return Icons.account_balance;
      case 'Custom':
        return Icons.description;
      default:
        return Icons.local_offer;
    }
  }

  IconData _getFileIcon(String extension) {
    switch (extension.toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'doc':
      case 'docx':
        return Icons.description;
      case 'mp4':
      case 'mov':
      case 'avi':
        return Icons.videocam;
      default:
        return Icons.insert_drive_file;
    }
  }

  Color _getFileColor(String extension) {
    switch (extension.toLowerCase()) {
      case 'pdf':
        return Colors.red;
      case 'doc':
      case 'docx':
        return Colors.blue;
      case 'mp4':
      case 'mov':
      case 'avi':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM dd, yyyy').format(date);
  }

  String _formatAmount(double amount) {
    final formatter = NumberFormat('#,##0.00');
    return formatter.format(amount);
  }

  String _formatFieldName(String fieldName) {
    // Convert camelCase to Title Case
    return fieldName
        .replaceAllMapped(RegExp(r'([A-Z])'), (match) => ' ${match.group(0)}')
        .split(' ')
        .map((word) => word.isEmpty ? '' : word[0].toUpperCase() + word.substring(1))
        .join(' ')
        .trim();
  }

  String _formatFieldValue(dynamic value) {
    if (value == null) return 'N/A';
    if (value is bool) return value ? 'Yes' : 'No';
    if (value is num) return value.toString();

    // Handle Firestore Timestamp
    if (value is Timestamp) {
      return _formatDate(value.toDate());
    }

    // Handle DateTime
    if (value is DateTime) {
      return _formatDate(value);
    }

    return value.toString();
  }

  String _getFileNameFromUrl(String url) {
    try {
      final uri = Uri.parse(url);
      final segments = uri.pathSegments;
      if (segments.isNotEmpty) {
        return segments.last.split('?').first;
      }
      return 'file';
    } catch (e) {
      return 'file';
    }
  }

  String _getFileExtension(String url) {
    try {
      final fileName = _getFileNameFromUrl(url);
      final parts = fileName.split('.');
      if (parts.length > 1) {
        return parts.last;
      }
      return 'file';
    } catch (e) {
      return 'file';
    }
  }

  Future<void> _downloadFile(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Could not open file'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error opening file: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

}