
import 'package:cloud_firestore/cloud_firestore.dart';

class DealModel {
  final String dealId;
  final String dealType;
  final String dealTitle;
  final String otherParty;
  final String otherPartyPhone;
  final String otherPartyEmail;
  final String otherPartyCnic;
  final String otherPartyUserId;
  final double? amount;
  final String description;
  final String currency;
  final DateTime date;
  final DateTime? dueDate;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String userId;

  // Type-specific data stored as a map
  final Map<String, dynamic>? typeSpecificData;

  final TermsAcceptance? termsAcceptance; // Add this field

  // Evidence
  final EvidenceData? evidence;

  // Status for tracking
  final String status; // 'draft', 'submitted', 'active', 'completed'

  DealModel({
    required this.dealId,
    required this.dealType,
    required this.dealTitle,
    required this.otherParty,
    required this.otherPartyPhone,
    required this.otherPartyEmail,
    required this.otherPartyCnic,
    required this.otherPartyUserId,
    this.amount,
    required this.description,
    required this.currency,
    required this.date,
    this.dueDate,
    required this.createdAt,
    required this.updatedAt,
    required this.userId,
    this.typeSpecificData,
    this.evidence,
    this.status = 'pending',
    this.termsAcceptance, // Add this

  });

  // Convert to Firestore format
  Map<String, dynamic> toFirestore() {
    return {
      'dealId': dealId,
      'dealType': dealType,
      'dealTitle': dealTitle,
      'otherParty': otherParty,
      'otherPartyPhone': otherPartyPhone,
      'otherPartyEmail': otherPartyEmail,
      'otherPartyCnic': otherPartyCnic,
      'otherPartyUserId': otherPartyUserId,
      'amount': amount,
      'description': description,
      'currency': currency,
      'date': Timestamp.fromDate(date),
      'dueDate': dueDate != null ? Timestamp.fromDate(dueDate!) : null,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'userId': userId,
      'status': status,
      'termsAcceptance': termsAcceptance?.toMap(), // Add this
      if (typeSpecificData != null) _getDealTypeKey(): typeSpecificData,
      if (evidence != null) 'evidence': evidence!.toMap(),
    };
  }

  // Get the correct key based on deal type
  String _getDealTypeKey() {
    switch (dealType) {
      case 'Goods Purchase':
        return 'goodsPurchase';
      case 'Rental':
        return 'rental';
      case 'Services':
        return 'services';
      case 'Freelance':
        return 'freelance';
      case 'Loan agreement':
        return 'loan';
      case 'Custom':
        return 'custom';
      default:
        return 'typeSpecificData';
    }
  }

  // Create from Firestore document
  factory DealModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return DealModel(
      dealId: doc.id,
      dealType: data['dealType'] ?? '',
      dealTitle: data['dealTitle'] ?? '',
      otherParty: data['otherParty'] ?? '',
      otherPartyPhone: data['otherPartyPhone'],
      otherPartyEmail: data['otherPartyEmail'],
      otherPartyCnic: data['otherPartyCnic'],
      otherPartyUserId: data['otherPartyUserId'],
      amount: data['amount']?.toDouble(),
      description: data['description'] ?? '',
      currency: data['currency'] ?? 'PKR',
      date: (data['date'] as Timestamp?)?.toDate() ?? DateTime.now(),
      dueDate: (data['dueDate'] as Timestamp?)?.toDate(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      userId: data['userId'] ?? '',
      status: data['status'] ?? 'pending',
      typeSpecificData: _extractTypeSpecificData(data),
      termsAcceptance: data['termsAcceptance'] != null
          ? TermsAcceptance.fromMap(data['termsAcceptance'])
          : null, // Add this
      evidence: data['evidence'] != null
          ? EvidenceData.fromMap(data['evidence'] as Map<String, dynamic>)
          : null,
    );
  }

  // Extract type-specific data from Firestore document
  static Map<String, dynamic>? _extractTypeSpecificData(Map<String, dynamic> data) {
    final keys = ['goodsPurchase', 'rental', 'services', 'freelance', 'loan', 'custom'];
    for (var key in keys) {
      if (data.containsKey(key) && data[key] != null) {
        return Map<String, dynamic>.from(data[key]);
      }
    }
    return null;
  }

  // Create a copy with updated fields
  DealModel copyWith({
    String? dealId,
    String? dealType,
    String? dealTitle,
    String? otherParty,
    String? otherPartyPhone,
    String? otherPartyEmail,
    String? otherPartyCnic,
    String? otherPartyUserId,
    double? amount,
    String? description,
    String? currency,
    DateTime? date,
    DateTime? dueDate,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? userId,
    Map<String, dynamic>? typeSpecificData,
    EvidenceData? evidence,
    String? status,
  }) {
    return DealModel(
      dealId: dealId ?? this.dealId,
      dealType: dealType ?? this.dealType,
      dealTitle: dealTitle ?? this.dealTitle,
      otherParty: otherParty ?? this.otherParty,
      otherPartyPhone: otherPartyPhone ?? this.otherPartyPhone,
      otherPartyEmail: otherPartyEmail ?? this.otherPartyEmail,
      otherPartyCnic: otherPartyCnic ?? this.otherPartyCnic,
      otherPartyUserId: otherPartyUserId ?? this.otherPartyUserId,
      amount: amount ?? this.amount,
      description: description ?? this.description,
      currency: currency ?? this.currency,
      date: date ?? this.date,
      dueDate: dueDate ?? this.dueDate,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      userId: userId ?? this.userId,
      typeSpecificData: typeSpecificData ?? this.typeSpecificData,
      evidence: evidence ?? this.evidence,
      status: status ?? this.status,
    );
  }
}

// Evidence Data Model
class EvidenceData {
  final String? recordedVideoUrl;
  final List<String> images;
  final List<String> invoices;
  final List<String> payments;
  final List<String> others;

  EvidenceData({
    this.recordedVideoUrl,
    this.images = const [],
    this.invoices = const [],
    this.payments = const [],
    this.others = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'recordedVideoUrl': recordedVideoUrl,
      'images': images,
      'invoices': invoices,
      'payments': payments,
      'others': others,
    };
  }

  factory EvidenceData.fromMap(Map<String, dynamic> map) {
    return EvidenceData(
      recordedVideoUrl: map['recordedVideoUrl'] as String?,
      images: List<String>.from(map['images'] ?? []),
      invoices: List<String>.from(map['invoices'] ?? []),
      payments: List<String>.from(map['payments'] ?? []),
      others: List<String>.from(map['others'] ?? []),
    );
  }

  EvidenceData copyWith({
    String? recordedVideoUrl,
    List<String>? images,
    List<String>? invoices,
    List<String>? payments,
    List<String>? others,
  }) {
    return EvidenceData(
      recordedVideoUrl: recordedVideoUrl ?? this.recordedVideoUrl,
      images: images ?? this.images,
      invoices: invoices ?? this.invoices,
      payments: payments ?? this.payments,
      others: others ?? this.others,
    );
  }
}


// lib/services/terms_service.dart


class TermsAndConditions {
  final String dealType;
  final String title;
  final String introduction;
  final List<String> terms;
  final String version;
  final DateTime lastUpdated;

  TermsAndConditions({
    required this.dealType,
    required this.title,
    required this.introduction,
    required this.terms,
    required this.version,
    required this.lastUpdated,
  });

  factory TermsAndConditions.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TermsAndConditions(
      dealType: doc.id,
      title: data['title'] ?? 'Terms and Conditions',
      introduction: data['introduction'] ?? '',
      terms: List<String>.from(data['terms'] ?? []),
      version: data['version'] ?? '1.0',
      lastUpdated: (data['lastUpdated'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'introduction': introduction,
      'terms': terms,
      'version': version,
      'lastUpdated': Timestamp.fromDate(lastUpdated),
    };
  }
}

class TermsAcceptance {
  final String version;
  final DateTime acceptedAt;
  final String dealType;

  TermsAcceptance({
    required this.version,
    required this.acceptedAt,
    required this.dealType,
  });

  Map<String, dynamic> toMap() {
    return {
      'version': version,
      'acceptedAt': Timestamp.fromDate(acceptedAt),
      'dealType': dealType,
    };
  }

  factory TermsAcceptance.fromMap(Map<String, dynamic> map) {
    return TermsAcceptance(
      version: map['version'] ?? '1.0',
      acceptedAt: (map['acceptedAt'] as Timestamp).toDate(),
      dealType: map['dealType'] ?? '',
    );
  }
}

