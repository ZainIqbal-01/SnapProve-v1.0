import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../model/deal_model.dart';

class DealsProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<DealModel> _deals = [];
  List<DealModel> _filteredDeals = [];
  bool _isLoading = false;
  String _searchQuery = '';
  String _filterDealType = 'all'; // all, Goods Purchase, Rental, Services, Freelance, Loan agreement, Custom
  String _filterStatus = 'all'; // all, pending, completed, cancelled

  List<DealModel> get deals => _filteredDeals;
  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;
  String get filterDealType => _filterDealType;
  String get filterStatus => _filterStatus;

  // Fetch all deals
  Future<void> fetchDeals() async {
    _isLoading = true;
    notifyListeners();

    try {
      final QuerySnapshot snapshot = await _firestore.collection('deals').get();
      _deals = snapshot.docs.map((doc) => DealModel.fromFirestore(doc)).toList();

      // Sort by created date (newest first)
      _deals.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _applyFilters();
    } catch (e) {
      print('Error fetching deals: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Search deals
  void searchDeals(String query) {
    _searchQuery = query.toLowerCase();
    _applyFilters();
    notifyListeners();
  }

  // Filter deals by type
  void filterByDealType(String dealType) {
    _filterDealType = dealType;
    _applyFilters();
    notifyListeners();
  }

  // Filter deals by status
  void filterByStatus(String status) {
    _filterStatus = status;
    _applyFilters();
    notifyListeners();
  }

  // Apply filters and search
  void _applyFilters() {
    _filteredDeals = _deals.where((deal) {
      // Search filter
      final matchesSearch = _searchQuery.isEmpty ||
          deal.dealTitle.toLowerCase().contains(_searchQuery) ||
          deal.otherParty.toLowerCase().contains(_searchQuery) ||
          deal.description.toLowerCase().contains(_searchQuery) ||
          deal.dealId.toLowerCase().contains(_searchQuery);

      // Deal type filter
      final matchesDealType = _filterDealType == 'all' || deal.dealType == _filterDealType;

      // Status filter
      final matchesStatus = _filterStatus == 'all' || deal.status == _filterStatus;

      return matchesSearch && matchesDealType && matchesStatus;
    }).toList();
  }

  // Update deal status
  Future<bool> updateDealStatus(String dealId, String newStatus) async {
    try {
      await _firestore.collection('deals').doc(dealId).update({
        'status': newStatus,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Update local state
      final index = _deals.indexWhere((deal) => deal.dealId == dealId);
      if (index != -1) {
        _deals[index] = _deals[index].copyWith(
          status: newStatus,
          updatedAt: DateTime.now(),
        );
        _applyFilters();
        notifyListeners();
      }

      return true;
    } catch (e) {
      print('Error updating deal status: $e');
      return false;
    }
  }

  // Get deal by ID
  DealModel? getDealById(String dealId) {
    try {
      return _deals.firstWhere((deal) => deal.dealId == dealId);
    } catch (e) {
      return null;
    }
  }

  // Refresh single deal data
  Future<DealModel?> refreshDealData(String dealId) async {
    try {
      final doc = await _firestore.collection('deals').doc(dealId).get();
      if (doc.exists) {
        final deal = DealModel.fromFirestore(doc);
        final index = _deals.indexWhere((d) => d.dealId == dealId);
        if (index != -1) {
          _deals[index] = deal;
          _applyFilters();
          notifyListeners();
        }
        return deal;
      }
      return null;
    } catch (e) {
      print('Error refreshing deal data: $e');
      return null;
    }
  }

  // Delete deal
  Future<bool> deleteDeal(String dealId) async {
    try {
      await _firestore.collection('deals').doc(dealId).delete();

      // Update local state
      _deals.removeWhere((deal) => deal.dealId == dealId);
      _applyFilters();
      notifyListeners();

      return true;
    } catch (e) {
      print('Error deleting deal: $e');
      return false;
    }
  }

  // Get statistics
  Map<String, int> getStatistics() {
    return {
      'total': _deals.length,
      'pending': _deals.where((d) => d.status == 'pending').length,
      'completed': _deals.where((d) => d.status == 'completed').length,
      'rejected': _deals.where((d) => d.status == 'rejected').length,
    };
  }

  // Get deals by user
  List<DealModel> getDealsByUser(String userId) {
    return _deals.where((deal) => deal.userId == userId).toList();
  }
}