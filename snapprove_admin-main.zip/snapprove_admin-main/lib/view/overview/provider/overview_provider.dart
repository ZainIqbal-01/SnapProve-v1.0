import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

/// One month's count, kept in chronological order.
class MonthData {
  final String label; // e.g. "Aug"
  final int count;

  const MonthData(this.label, this.count);
}

class OverviewProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ── stat card numbers ─────────────────────────────────────────────────────
  int _totalDeals = 0;
  int _completedDeals = 0;
  int _pendingDeals = 0;
  int _totalUsers = 0;

  int get totalDeals => _totalDeals;
  int get completedDeals => _completedDeals;
  int get pendingDeals => _pendingDeals;
  int get totalUsers => _totalUsers;

  // ── chart data (last 6 months, chronological) ────────────────────────────
  List<MonthData> _dealsPerMonth = [];
  List<MonthData> _usersPerMonth = [];

  List<MonthData> get dealsPerMonth => _dealsPerMonth;
  List<MonthData> get usersPerMonth => _usersPerMonth;

  // ── loading ───────────────────────────────────────────────────────────────
  bool _isLoading = true;
  bool get isLoading => _isLoading;

  // ── public ────────────────────────────────────────────────────────────────

  Future<void> fetchAll() async {
    _isLoading = true;
    notifyListeners();

    try {
      await Future.wait([
        _fetchDealStats(),
        _fetchUserStats(),
        _fetchDealsPerMonth(),
        _fetchUsersPerMonth(),
      ]);

      // Debug output
      debugPrint('📊 Overview Stats:');
      debugPrint('   Total Deals: $_totalDeals');
      debugPrint('   Completed: $_completedDeals');
      debugPrint('   Pending: $_pendingDeals');
      debugPrint('   Total Users: $_totalUsers');
      debugPrint('📈 Deals per month: ${_dealsPerMonth.map((m) => '${m.label}:${m.count}').join(', ')}');
      debugPrint('📈 Users per month: ${_usersPerMonth.map((m) => '${m.label}:${m.count}').join(', ')}');
    } catch (e) {
      debugPrint('OverviewProvider error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ── private helpers ───────────────────────────────────────────────────────

  Future<void> _fetchDealStats() async {
    final all = await _firestore.collection('deals').get();
    _totalDeals = all.size;

    int completed = 0;
    int pending = 0;
    for (final doc in all.docs) {
      final status = (doc.data()['status'] as String?);
      if (status == 'completed') completed++;
      if (status == 'pending') pending++;
    }
    _completedDeals = completed;
    _pendingDeals = pending;
  }

  Future<void> _fetchUserStats() async {
    final snap = await _firestore.collection('users').get();
    _totalUsers = snap.size;
  }

  Future<void> _fetchDealsPerMonth() async {
    _dealsPerMonth = await _bucketByMonth('deals');
  }

  Future<void> _fetchUsersPerMonth() async {
    _usersPerMonth = await _bucketByMonth('users');
  }

  /// Generic: query a collection, bucket every doc's createdAt into the
  /// last 6 calendar months (current month included), return chronological list.
  Future<List<MonthData>> _bucketByMonth(String collection) async {
    final now = DateTime.now();

    // Build 6 month boundaries (start of each month) - FIXED VERSION
    final months = <DateTime>[];
    for (int i = 5; i >= 0; i--) {
      // Use DateTime's built-in month handling which correctly handles negative values
      final targetDate = DateTime(now.year, now.month - i, 1);
      months.add(targetDate);
    }
    // months[0] = oldest (6 months ago), months[5] = current month start

    // Upper bound = start of next month
    final upperBound = DateTime(now.year, now.month + 1, 1);

    debugPrint('🔍 Fetching $collection from ${months[0]} to $upperBound');

    // Fetch docs created on or after the oldest month start.
    final snap = await _firestore
        .collection(collection)
        .where('createdAt', isGreaterThanOrEqualTo: Timestamp.fromDate(months[0]))
        .where('createdAt', isLessThan: Timestamp.fromDate(upperBound))
        .get();

    debugPrint('   Found ${snap.docs.length} documents in $collection');

    // Initialize bucket counts.
    final counts = List.filled(6, 0);

    for (final doc in snap.docs) {
      final raw = doc.data()['createdAt'];
      DateTime? createdAt;

      if (raw is Timestamp) {
        createdAt = raw.toDate();
      } else if (raw is String) {
        createdAt = DateTime.tryParse(raw);
      }

      if (createdAt == null) {
        debugPrint('   ⚠️  Document ${doc.id} has invalid createdAt: $raw');
        continue;
      }

      debugPrint('   📅 Document ${doc.id}: ${createdAt.toString().substring(0, 10)}');

      // Find which bucket this date falls into.
      for (int i = 5; i >= 0; i--) {
        if (!createdAt.isBefore(months[i])) {
          counts[i]++;
          debugPrint('      ➡️  Assigned to bucket $i (${months[i].month})');
          break;
        }
      }
    }

    // Build labelled list.
    final labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final result = List.generate(6, (i) {
      final monthIndex = months[i].month - 1; // 0-based for labels array
      return MonthData(labels[monthIndex], counts[i]);
    });

    debugPrint('   📊 Final buckets: ${result.map((m) => '${m.label}:${m.count}').join(', ')}');

    return result;
  }
}