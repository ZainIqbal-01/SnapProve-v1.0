import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/common/services/responsvie_services.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import '../provider/overview_provider.dart';

class Overview extends StatefulWidget {
  const Overview({super.key});

  @override
  State<Overview> createState() => _OverviewState();
}

class _OverviewState extends State<Overview> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<OverviewProvider>().fetchAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = Responsive.isMobile(context);
    final isTablet = Responsive.isTablet(context);

    return Consumer<OverviewProvider>(
      builder: (context, provider, _) {
        if (provider.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        return SingleChildScrollView(
          padding: EdgeInsets.all(isMobile ? 12.0 : (isTablet ? 16.0 : 20.0)),
          child: Column(
            children: [
              // ── Stat cards ──────────────────────────────────────────────
              _buildStatisticsSection(context, provider, isMobile, isTablet),
              SizedBox(height: isMobile ? 20 : 30),

              // ── Charts ──────────────────────────────────────────────────
              _buildChartsSection(context, provider, isMobile, isTablet),
            ],
          ),
        );
      },
    );
  }

  // ── STAT CARDS ────────────────────────────────────────────────────────────

  Widget _buildStatisticsSection(
      BuildContext context,
      OverviewProvider provider,
      bool isMobile,
      bool isTablet,
      ) {
    final stats = [
      _StatData(
        title: 'Total Deals',
        value: provider.totalDeals.toString(),
        icon: Icons.local_offer,
        color: Colors.blue,
      ),
      _StatData(
        title: 'Completed Deals',
        value: provider.completedDeals.toString(),
        icon: Icons.check_circle_outline,
        color: Colors.green,
      ),
      _StatData(
        title: 'Pending Deals',
        value: provider.pendingDeals.toString(),
        icon: Icons.pending_outlined,
        color: Colors.orange,
      ),
      _StatData(
        title: 'Total Users',
        value: provider.totalUsers.toString(),
        icon: Icons.people_outlined,
        color: Colors.purple,
      ),
    ];

    // Mobile: 2-column wrap
    if (isMobile) {
      return Wrap(
        spacing: 12,
        runSpacing: 12,
        children: stats.map((stat) {
          return SizedBox(
            width: (MediaQuery.of(context).size.width - 24 - 24) / 2,
            child: _buildStatCard(
              title: stat.title,
              value: stat.value,
              icon: stat.icon,
              color: stat.color,
              isMobile: true,
            ),
          );
        }).toList(),
      );
    }

    // Tablet: 2-column wrap
    if (isTablet) {
      return Wrap(
        spacing: 16,
        runSpacing: 16,
        children: stats.map((stat) {
          return SizedBox(
            width: (MediaQuery.of(context).size.width - 80 - 48) / 2,
            child: _buildStatCard(
              title: stat.title,
              value: stat.value,
              icon: stat.icon,
              color: stat.color,
            ),
          );
        }).toList(),
      );
    }

    // Desktop: 4-column row
    return Row(
      children: List.generate(stats.length, (i) {
        final stat = stats[i];
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i < stats.length - 1 ? 20 : 0),
            child: _buildStatCard(
              title: stat.title,
              value: stat.value,
              icon: stat.icon,
              color: stat.color,
            ),
          ),
        );
      }),
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    bool isMobile = false,
  }) {
    return Container(
      padding: EdgeInsets.all(isMobile ? 16 : 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: isMobile ? 22 : 26),
          ),
          SizedBox(height: 14),
          Text(
            title,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: isMobile ? 12 : 14,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: isMobile ? 24 : 30,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // ── CHARTS ────────────────────────────────────────────────────────────────

  Widget _buildChartsSection(
      BuildContext context,
      OverviewProvider provider,
      bool isMobile,
      bool isTablet,
      ) {
    final dealsChart = _buildLineChartCard(
      title: 'Deals Growth',
      data: provider.dealsPerMonth,
      color: Colors.blue,
      height: isMobile ? 240 : (isTablet ? 260 : 280),
    );

    final usersChart = _buildLineChartCard(
      title: 'Users Growth',
      data: provider.usersPerMonth,
      color: Colors.purple,
      height: isMobile ? 240 : (isTablet ? 260 : 280),
    );

    // Mobile / Tablet → stack
    if (isMobile || isTablet) {
      return Column(
        children: [
          dealsChart,
          const SizedBox(height: 16),
          usersChart,
        ],
      );
    }

    // Desktop → side by side (equal width)
    return Row(
      children: [
        Expanded(child: dealsChart),
        const SizedBox(width: 20),
        Expanded(child: usersChart),
      ],
    );
  }

  Widget _buildLineChartCard({
    required String title,
    required List<MonthData> data,
    required Color color,
    required double height,
  }) {
    // Guard: if data is somehow empty, fill with 6 zeroes so the chart does not crash.
    final safeData = data.isNotEmpty
        ? data
        : List.generate(6, (_) => const MonthData('—', 0));

    // Compute a nice max for the Y axis (at least 1, rounded up to next multiple of 5).
    final maxVal = safeData.fold<int>(0, (prev, d) => prev > d.count ? prev : d.count);
    final yMax = maxVal < 1 ? 5.0 : ((maxVal / 5.0).ceil() * 5).toDouble();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row: title + legend dot
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Last 6 months',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),

          // The chart
          SizedBox(
            height: height,
            child: LineChart(
              LineChartData(
                // ── grid & border ─────────────────────────────────────────
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: yMax / 4,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: Colors.grey.shade200,
                      strokeWidth: 1,
                    );
                  },
                ),
                borderData: FlBorderData(
                  show: true,
                  border: Border(
                    bottom: BorderSide(color: Colors.grey.shade300, width: 1),
                    left: BorderSide(color: Colors.grey.shade300, width: 1),
                  ),
                ),

                // ── axes ──────────────────────────────────────────────────
                minX: 0,
                maxX: 5,
                minY: 0,
                maxY: yMax,
                titlesData: FlTitlesData(
                  // X (bottom)
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      interval: 1,
                      getTitlesWidget: (value, meta) {
                        final i = value.toInt();
                        if (i < 0 || i > 5) return const SizedBox();
                        return Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            safeData[i].label,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  // Y (left)
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 36,
                      interval: yMax / 4,
                      getTitlesWidget: (value, meta) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 4),
                          child: Text(
                            value.toInt().toString(),
                            style: TextStyle(
                              fontSize: 11,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  // Hide right & top
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),

                // ── tooltip ───────────────────────────────────────────────
                lineTouchData: LineTouchData(
                  touchTooltipData: LineTouchTooltipData(
                    getTooltipColor: (touchedSpot) => Colors.white.withOpacity(0.95),
                    tooltipRoundedRadius: 8,
                    tooltipBorder: BorderSide(color: color.withOpacity(0.4)),
                    getTooltipItems: (spots) {
                      return spots.map((spot) {
                        final i = spot.x.toInt();
                        final label = (i >= 0 && i < safeData.length)
                            ? safeData[i].label
                            : '';
                        return LineTooltipItem(
                          '${spot.y.toInt()}',
                          TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: color,
                          ),
                          children: [
                            TextSpan(
                              text: '\n$label',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        );
                      }).toList();
                    },
                  ),
                ),

                // ── line data ─────────────────────────────────────────────
                lineBarsData: [
                  LineChartBarData(
                    spots: List.generate(
                      safeData.length,
                          (i) => FlSpot(i.toDouble(), safeData[i].count.toDouble()),
                    ),
                    color: color,
                    barWidth: 3,
                    isCurved: true,
                    curveSmoothness: 0.3,
                    dotData: FlDotData(
                      show: true,
                      getDotPainter: (spot, percent, barData, index) {
                        return FlDotCirclePainter(
                          radius: 4,
                          color: color,
                          strokeWidth: 2,
                          strokeColor: Colors.white,
                        );
                      },
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          color.withOpacity(0.18),
                          color.withOpacity(0.0),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── tiny helpers ──────────────────────────────────────────────────────────────

class _StatData {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  _StatData({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });
}