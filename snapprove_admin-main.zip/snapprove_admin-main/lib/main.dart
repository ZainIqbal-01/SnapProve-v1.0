import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:snap_prove_admin/theme/app_colors.dart';
import 'package:snap_prove_admin/view/auth/provider/checkbox_provider.dart';
import 'package:snap_prove_admin/view/auth/provider/loader_view_provider.dart';
import 'package:snap_prove_admin/view/auth/provider/obsecure_provider.dart';
import 'package:snap_prove_admin/view/deals/provider/deal_provider.dart';
import 'package:snap_prove_admin/view/landing_view/provider/landing_view_provider.dart';
import 'package:snap_prove_admin/view/overview/provider/overview_provider.dart';
import 'package:snap_prove_admin/view/settings/provider/settings_provider.dart';
import 'package:snap_prove_admin/view/splash/splash_screen.dart';
import 'package:snap_prove_admin/view/terms_and_conditions/provider/terms&conditions_provider.dart';
import 'package:snap_prove_admin/view/users/provider/user_provider.dart';
import 'firebase_options.dart';

import 'common/services/responsvie_services.dart';

void main()async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final designSize = Responsive.screenUtilDesignSize(constraints.maxWidth);

        return ScreenUtilInit(
          designSize: designSize,
          minTextAdapt: true,
          splitScreenMode: true,
          builder: (_, child) =>  MultiProvider(
            providers: [
              ChangeNotifierProvider(create: (_) => CheckBoxProvider()),
              ChangeNotifierProvider(create: (_) => ObscureProvider()),
              ChangeNotifierProvider(create: (_) => LoaderViewProvider()),
              ChangeNotifierProvider(create: (_) => LandingViewProvider()),
              ChangeNotifierProvider(create: (_) => UsersProvider()),
              ChangeNotifierProvider(create: (_) => DealsProvider()),
              ChangeNotifierProvider(create: (_) => TermsConditionsProvider()),
              ChangeNotifierProvider(create: (_) => SettingsProvider()),
              ChangeNotifierProvider(create: (_) => OverviewProvider()),


              // ChangeNotifierProvider(create: (_) => ChatProvider('', context)),






            ],
            child: MaterialApp(
                title: 'SnapProve',
                debugShowCheckedModeBanner: false,
                theme: ThemeData(
                  colorScheme: ColorScheme.fromSeed(seedColor: AppColors.secondary),
                  appBarTheme: const AppBarTheme(
                    systemOverlayStyle: SystemUiOverlayStyle(
                      statusBarColor: Colors.transparent,
                      statusBarIconBrightness: Brightness.dark,
                    ),
                  ),
                ),
                home: const SplashScreen(),
              ),
          ),
          );
      },
    );
  }
}

